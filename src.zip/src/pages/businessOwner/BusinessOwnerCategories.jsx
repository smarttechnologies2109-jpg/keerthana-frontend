import React, {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useLocation,
  useNavigate,
} from "react-router-dom";

import {
  FaArrowLeft,
  FaFolderOpen,
  FaSearch,
  FaFilter,
  FaTimes,
  FaMusic,
  FaGlobe,
  FaLanguage,
} from "react-icons/fa";

import API from "../../services/api";

import "../../assets/css/businessowner/BusinessOwnerCategories.css";



/* =========================================================
   LANGUAGES
========================================================= */

const LANGUAGES = [
  "Telugu",
  "Hindi",
  "English",
  "Malayalam",
  "Kannada",
  "Tamil",
];

/* Normalize language codes, locale strings and object-shaped API values. */
const firstNonEmpty = (...values) => {
  for (const value of values) {
    if (value && typeof value === "object") {
      const nested = firstNonEmpty(
        value.name, value.label, value.code, value.value,
        value.language, value.language_name
      );
      if (nested) return nested;
    } else if (value !== null && value !== undefined && String(value).trim()) {
      return String(value).trim();
    }
  }
  return "";
};

const normalizeLanguage = (value) => {
  const raw = firstNonEmpty(value)
    .toLowerCase()
    .replace(/_/g, "-")
    .replace(/[()]/g, "")
    .trim();

  if (!raw) return "";

  const aliases = {
    te: "telugu", "te-in": "telugu", telugu: "telugu",
    hi: "hindi", "hi-in": "hindi", hindi: "hindi",
    en: "english", "en-in": "english", english: "english",
    ml: "malayalam", "ml-in": "malayalam", malayalam: "malayalam",
    kn: "kannada", "kn-in": "kannada", kannada: "kannada",
    ta: "tamil", "ta-in": "tamil", tamil: "tamil",
  };

  if (aliases[raw]) return aliases[raw];
  const prefix = raw.split(/[-\s]/)[0];
  return aliases[prefix] || raw.replace(/\s+/g, " ");
};

const getCategoryLanguage = (category) => {
  const detected = normalizeLanguage(firstNonEmpty(
    category?.language,
    category?.language_name,
    category?.languageName,
    category?.language_code,
    category?.languageCode,
    category?.category_language,
    category?.categoryLanguage,
    category?.lang
  ));

  // The Admin Manage Categories form currently does not save a language field.
  // Admin treats categories without a language as Telugu, so keep both pages
  // consistent. Explicit language values always take priority.
  return detected || "telugu";
};

const hasTeluguScript = (value) => /[\u0C00-\u0C7F]/.test(String(value || ""));

const getCategoryNames = (category) => {
  const explicitEnglish = firstNonEmpty(
    category?.name_english,
    category?.english_name,
    category?.nameEnglish,
    category?.category_name_english,
    category?.categoryNameEnglish,
    category?.category_name_en,
    category?.name_en,
    category?.nameEn,
    category?.englishName,
    category?.title_english,
    category?.title_en,
    category?.names?.english,
    category?.names?.en,
    category?.translations?.en,
    category?.translations?.english,
    category?.category?.name_english,
    category?.category?.english_name,
    category?.category?.name_en
  );

  const generic = firstNonEmpty(
    category?.name,
    category?.category_name,
    category?.categoryName,
    category?.title
  );

  const english = explicitEnglish || (!hasTeluguScript(generic) ? generic : "");
  return { english: english || "English name not provided by API" };
};

const getEnglishDescription = (category) => {
  const explicitEnglish = firstNonEmpty(
    category?.description_english,
    category?.english_description,
    category?.descriptionEnglish,
    category?.description_en,
    category?.bio_english,
    category?.english_bio
  );
  const generic = firstNonEmpty(category?.description);
  const value = explicitEnglish || (!hasTeluguScript(generic) ? generic : "");
  return value || "";
};

const extractCategoryArray = (payload) => {
  if (Array.isArray(payload)) return payload;
  const candidates = [
    payload?.categories, payload?.data, payload?.results,
    payload?.items, payload?.records,
    payload?.data?.categories, payload?.data?.results,
    payload?.data?.items, payload?.data?.records,
    payload?.result?.categories, payload?.result?.data,
    payload?.response?.categories, payload?.response?.data,
    payload?.data?.data?.categories
  ];
  const found = candidates.find(Array.isArray) || [];
  const seen = new Set();
  return found.filter((category, index) => {
    const key = category?.id ?? category?.category_id ?? `row-${index}`;
    if (seen.has(String(key))) return false;
    seen.add(String(key));
    return true;
  });
};

/* =========================================================
   BUSINESS OWNER CATEGORIES
========================================================= */

const BusinessOwnerCategories = () => {

  const navigate = useNavigate();

  const location = useLocation();


  /* =======================================================
     STATE
  ======================================================= */

  const [categories, setCategories] = useState([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");

  const [search, setSearch] = useState("");

  const [language, setLanguage] = useState("");

  // PAGINATION
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);


  /* =======================================================
     READ LANGUAGE FROM URL
  ======================================================= */

  useEffect(() => {

    const params =
      new URLSearchParams(
        location.search
      );

    const urlLanguage =
      params.get("language");


    const matchedLanguage = LANGUAGES.find(
      (item) => normalizeLanguage(item) === normalizeLanguage(urlLanguage)
    );

    setLanguage(matchedLanguage || "");

  }, [location.search]);


  /* =======================================================
     LOAD CATEGORIES
  ======================================================= */

  useEffect(() => {

    const loadCategories = async () => {

      try {

        setLoading(true);

        setError("");

// Load the full collection once. Language cards and the dropdown
// filter this complete list locally, so counts remain accurate.
const response = await API.get("/owner/music/categories");


        const data = response?.data;
        setCategories(extractCategoryArray(data));

      }

      catch (err) {

        console.error(
          "Failed to load owner categories:",
          err
        );


        setError(
          err?.response?.data?.message ||
          "Unable to load categories."
        );

        setCategories([]);

      }

      finally {

        setLoading(false);

      }

    };


    loadCategories();

  }, []);


  /* =======================================================
     FILTER CATEGORIES
  ======================================================= */

  const filteredCategories = useMemo(() => {

    const searchText =
      search
        .trim()
        .toLowerCase();


    return categories.filter(
      (category) => {

        const names = getCategoryNames(category);
        const searchableNames = names.english.toLowerCase();
        const description = getEnglishDescription(category).toLowerCase();


        const categoryLanguage = getCategoryLanguage(category);

        const matchesSearch =
          !searchText ||
          searchableNames.includes(searchText) ||
          description.includes(searchText);


        const matchesLanguage =
          !language ||
          categoryLanguage === normalizeLanguage(language);


        return (
          matchesSearch &&
          matchesLanguage
        );

      }
    );

  }, [
    categories,
    search,
    language,
  ]);

  // Keep pagination in sync with the filtered collection.
  const totalPages = Math.max(1, Math.ceil(filteredCategories.length / pageSize));

  useEffect(() => {
    setCurrentPage(1);
  }, [search, language, pageSize]);

  useEffect(() => {
    setCurrentPage((page) => Math.min(page, totalPages));
  }, [totalPages]);

  const paginatedCategories = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return filteredCategories.slice(startIndex, startIndex + pageSize);
  }, [filteredCategories, currentPage, pageSize]);


  /* =======================================================
     LANGUAGE COUNTS
  ======================================================= */

  const languageCounts = useMemo(() => {
    const counts = Object.fromEntries(
      LANGUAGES.map((item) => [item, 0])
    );

    categories.forEach((category) => {
      const normalized = getCategoryLanguage(category);
      const matched = LANGUAGES.find(
        (item) => normalizeLanguage(item) === normalized
      );
      if (matched) counts[matched] += 1;
    });

    return counts;
  }, [categories]);


  /* =======================================================
     CLEAR FILTERS
  ======================================================= */

  const clearFilters = () => {

    setSearch("");

    setLanguage("");


    navigate(
      "/owner/music/categories",
      {
        replace: true,
      }
    );

  };


  /* =======================================================
     LANGUAGE CHANGE
  ======================================================= */

  const handleLanguageChange = (
    event
  ) => {

    const selectedLanguage =
      event.target.value;


    setLanguage(
      selectedLanguage
    );


    if (selectedLanguage) {

      navigate(
        `/owner/music/categories?language=${encodeURIComponent(
          selectedLanguage
        )}`,
        {
          replace: true,
        }
      );

    } else {

      navigate(
        "/owner/music/categories",
        {
          replace: true,
        }
      );

    }

  };


  /* =======================================================
     CATEGORY IMAGE
  ======================================================= */

  const getCategoryImage = (
    category
  ) => {

    return (
      category?.image_url ||
      category?.imageUrl ||
      category?.category_image_url ||
      category?.cover_url ||
      category?.image ||
      "/images/default-category.png"
    );

  };


  /* =======================================================
     RENDER
  ======================================================= */

  return (

    <div className="owner-categories-page">
      <style>{`
        .owner-category-telugu-name { margin: 5px 0 0; color: #e3c77f; font-size: .95rem; font-weight: 600; line-height: 1.5; }
        .owner-categories-language-section { margin: 0 0 24px; }
        .owner-categories-language-heading { display:flex; align-items:center; justify-content:space-between; gap:14px; margin-bottom:14px; flex-wrap:wrap; }
        .owner-categories-language-heading h2 { margin:0 0 5px; color:#f7f3e9; font-size:1.12rem; }
        .owner-categories-language-heading p { margin:0; color:#aebbd0; font-size:.88rem; }
        .owner-categories-language-total { display:inline-flex; align-items:center; gap:8px; color:#e8d39a; font-weight:700; }
        .owner-categories-language-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(145px,1fr)); gap:12px; }
        .owner-categories-language-card { display:flex; flex-direction:column; align-items:flex-start; gap:7px; min-height:132px; padding:16px; border:1px solid rgba(207,177,112,.22); border-radius:16px; background:linear-gradient(145deg,rgba(20,39,72,.96),rgba(9,20,40,.98)); color:#f5f1e8; text-align:left; cursor:pointer; transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease; }
        .owner-categories-language-card:hover { transform:translateY(-3px); border-color:#d7b96e; box-shadow:0 10px 26px rgba(0,0,0,.22); }
        .owner-categories-language-card.active { border-color:#e0c27b; background:linear-gradient(145deg,rgba(35,69,119,.98),rgba(13,31,59,.98)); box-shadow:0 0 0 1px rgba(224,194,123,.25); }
        .owner-categories-language-card-icon { display:grid; place-items:center; width:30px; height:30px; border-radius:9px; background:rgba(220,190,119,.13); color:#e3c77f; }
        .owner-categories-language-card-label { color:#d4deed; font-size:.82rem; font-weight:600; }
        .owner-categories-language-card strong { color:#fff; font-size:1.55rem; line-height:1; }
        .owner-categories-language-card small { color:#aebbd0; font-size:.74rem; }
        @media(max-width:600px) { .owner-categories-language-grid { grid-template-columns:repeat(2,minmax(0,1fr)); } .owner-categories-language-card { min-height:120px; padding:13px; } }

        .owner-categories-table-wrapper {
          width: 100%;
          overflow-x: auto;
          border: 1px solid rgba(104, 153, 220, .22);
          border-radius: 16px;
          background: rgba(8, 19, 36, .72);
          scrollbar-width: thin;
          scrollbar-color: rgba(216, 184, 106, .55) rgba(10, 22, 43, .7);
        }

        .owner-categories-table {
          width: 100%;
          min-width: 650px;
          border-collapse: collapse;
          text-align: left;
        }

        .owner-categories-table thead {
          background: linear-gradient(110deg, rgba(29, 55, 91, .98), rgba(15, 32, 56, .98));
        }

        .owner-categories-table th {
          padding: 16px 18px;
          color: #e8d19b;
          font-size: .78rem;
          font-weight: 800;
          letter-spacing: .07em;
          text-transform: uppercase;
          white-space: nowrap;
          border-bottom: 1px solid rgba(216, 184, 106, .25);
        }

        .owner-categories-table td {
          padding: 13px 18px;
          color: #e8eef9;
          font-size: .9rem;
          border-bottom: 1px solid rgba(130, 157, 194, .13);
          vertical-align: middle;
        }

        .owner-categories-table tbody tr {
          transition: background .18s ease;
        }

        .owner-categories-table tbody tr:hover {
          background: rgba(55, 91, 143, .17);
        }

        .owner-categories-table tbody tr:last-child td {
          border-bottom: 0;
        }

        .owner-categories-row-number {
          width: 58px;
          color: #9fb0ca !important;
          font-weight: 700;
          font-variant-numeric: tabular-nums;
        }

        .owner-categories-table-category {
          display: flex;
          align-items: center;
          gap: 13px;
          min-width: 260px;
        }

        .owner-categories-table-image {
          flex: 0 0 54px;
          width: 54px;
          height: 54px;
          overflow: hidden;
          border-radius: 10px;
          background: linear-gradient(145deg, #19345b, #091428);
          border: 1px solid rgba(216, 184, 106, .24);
        }

        .owner-categories-table-image img {
          display: block;
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .owner-categories-table-category-name {
          display: flex;
          flex-direction: column;
          gap: 5px;
          min-width: 0;
        }

        .owner-categories-table-category-name strong {
          color: #f4f7ff;
          font-size: .94rem;
          font-weight: 750;
          overflow-wrap: anywhere;
        }

        .owner-categories-table-category-name span {
          color: #91a4c2;
          font-size: .74rem;
          line-height: 1.4;
          max-width: 460px;
        }

        .owner-categories-language-badge,
        .owner-categories-song-count {
          display: inline-flex;
          align-items: center;
          padding: 6px 11px;
          border: 1px solid rgba(104, 153, 220, .3);
          border-radius: 999px;
          background: rgba(32, 59, 96, .42);
          color: #dce8fb;
          font-size: .78rem;
          font-weight: 700;
          white-space: nowrap;
        }

        @media (max-width: 640px) {
          .owner-categories-table th,
          .owner-categories-table td {
            padding: 11px 12px;
          }

          .owner-categories-table-image {
            flex-basis: 46px;
            width: 46px;
            height: 46px;
          }

          .owner-categories-table-category-name strong {
            font-size: .86rem;
          }
        }

      `}</style>


      {/* ===================================================
          HEADER
      =================================================== */}

      <header className="owner-categories-header">


        <button
          type="button"
          className="owner-categories-back-button"
          onClick={() =>
            navigate(
              "/owner/music"
            )
          }
        >

          <FaArrowLeft />

          <span>
            Music Collection
          </span>

        </button>


        <div className="owner-categories-title-area">

          <div className="owner-categories-title-icon">

            <FaFolderOpen />

          </div>


          <div>

            <h1>
              Categories
            </h1>

            <p>
              View all categories in the
              KEERTHANA collection.
            </p>

          </div>

        </div>

      </header>


      {/* ===================================================
          CONTENT
      =================================================== */}

      <main className="owner-categories-content">


        {/* =================================================
            SUMMARY
        ================================================= */}

        <div className="owner-categories-summary">


          <div className="owner-categories-summary-card">

            <span>
              Total Categories
            </span>

            <strong>
              {categories.length}
            </strong>

          </div>


          <div className="owner-categories-summary-card">

            <span>
              Showing
            </span>

            <strong>
              {filteredCategories.length}
            </strong>

          </div>


          <div className="owner-categories-summary-card">

            <span>
              Language
            </span>

            <strong className="owner-categories-language-value">

              {language || "All"}

            </strong>

          </div>

        </div>

        {/* =================================================
            LANGUAGE CARDS
        ================================================= */}

        <section className="owner-categories-language-section">
          <div className="owner-categories-language-heading">
            <div>
              <h2>Categories by Language</h2>
              <p>Select a language to view its categories.</p>
            </div>
            <span className="owner-categories-language-total">
              <FaGlobe /> {categories.length} Total
            </span>
          </div>

          <div className="owner-categories-language-grid">
            <button
              type="button"
              className={`owner-categories-language-card ${!language ? "active" : ""}`}
              onClick={() => handleLanguageChange({ target: { value: "" } })}
            >
              <span className="owner-categories-language-card-icon"><FaGlobe /></span>
              <span className="owner-categories-language-card-label">All Languages</span>
              <strong>{categories.length}</strong>
              <small>All categories</small>
            </button>

            {LANGUAGES.map((item) => (
              <button
                type="button"
                key={item}
                className={`owner-categories-language-card ${language === item ? "active" : ""}`}
                onClick={() => handleLanguageChange({ target: { value: item } })}
              >
                <span className="owner-categories-language-card-icon"><FaLanguage /></span>
                <span className="owner-categories-language-card-label">{item}</span>
                <strong>{languageCounts[item]}</strong>
                <small>{languageCounts[item] === 1 ? "Category" : "Categories"}</small>
              </button>
            ))}
          </div>
        </section>


        {/* =================================================
            FILTER
        ================================================= */}

        <section className="owner-categories-filter-card">


          <div className="owner-categories-filter-title">

            <FaFilter />

            <span>
              Search & Filter
            </span>

          </div>


          <div className="owner-categories-filter-row">


            {/* SEARCH */}

            <div className="owner-categories-search">

              <FaSearch />

              <input
                type="text"
                value={search}
                onChange={(event) =>
                  setSearch(
                    event.target.value
                  )
                }
                placeholder="Search categories..."
              />


              {search && (

                <button
                  type="button"
                  className="owner-categories-clear-search"
                  onClick={() =>
                    setSearch("")
                  }
                  aria-label="Clear search"
                >

                  <FaTimes />

                </button>

              )}

            </div>


            {/* LANGUAGE */}

            <select
              value={language}
              onChange={
                handleLanguageChange
              }
              className="owner-categories-language-select"
            >

              <option value="">
                All Languages
              </option>

              {LANGUAGES.map(
                (item) => (

                  <option
                    key={item}
                    value={item}
                  >

                    {item}

                  </option>

                )
              )}

            </select>


            {/* CLEAR */}

            {(search || language) && (

              <button
                type="button"
                className="owner-categories-clear-button"
                onClick={clearFilters}
              >

                <FaTimes />

                Clear

              </button>

            )}

          </div>

        </section>


        {/* =================================================
            ERROR
        ================================================= */}

        {error && (

          <div className="owner-categories-error">

            {error}

          </div>

        )}


        {/* =================================================
            LOADING
        ================================================= */}

        {loading ? (

          <div className="owner-categories-loading">

            <div className="owner-categories-spinner"></div>

            <p>
              Loading categories...
            </p>

          </div>

        ) : filteredCategories.length === 0 ? (

          /* ===============================================
             EMPTY
          =============================================== */

          <div className="owner-categories-empty">

            <div className="owner-categories-empty-icon">

              <FaFolderOpen />

            </div>


            <h2>
              No Categories Found
            </h2>


            <p>

              {search || language
                ? "No categories match the selected search or language filter."
                : "There are no categories in the KEERTHANA collection yet."
              }

            </p>


            {(search || language) && (

              <button
                type="button"
                onClick={clearFilters}
                className="owner-categories-empty-button"
              >

                Clear Filters

              </button>

            )}

          </div>

        ) : (

          /* ===============================================
             CATEGORY GRID
          =============================================== */

          <section className="owner-categories-list-card">


            <div className="owner-categories-list-header">

              <div>

                <h2>
                  Category Collection
                </h2>

                <p>
                  {filteredCategories.length} categor
                  {filteredCategories.length !== 1
                    ? "ies"
                    : "y"}
                  {" "}displayed
                </p>

              </div>

            </div>


            <div className="owner-categories-table-wrapper">
              <table className="owner-categories-table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Category</th>
                    <th scope="col">Language</th>
                    <th scope="col">Total Songs</th>
                  </tr>
                </thead>

                <tbody>
                  {paginatedCategories.map((category, index) => {
                    const image = getCategoryImage(category);
                    const name = getCategoryNames(category).english || "Category";
                    const categoryLanguage =
                      LANGUAGES.find(
                        (item) =>
                          normalizeLanguage(item) === getCategoryLanguage(category)
                      ) || "Telugu";
                    const songCount =
                      category?.song_count ??
                      category?.songs_count ??
                      category?.total_songs ??
                      null;

                    return (
                      <tr
                        key={
                          category?.id ||
                          category?.category_id ||
                          `${name}-${index}`
                        }
                      >
                        <td className="owner-categories-row-number">
                          {(currentPage - 1) * pageSize + index + 1}
                        </td>

                        <td>
                          <div className="owner-categories-table-category">
                            <div className="owner-categories-table-image">
                              <img
                                src={image}
                                alt={name}
                                loading="lazy"
                                onError={(event) => {
                                  event.currentTarget.onerror = null;
                                  event.currentTarget.src =
                                    "/images/default-category.png";
                                }}
                              />
                            </div>

                            <div className="owner-categories-table-category-name">
                              <strong>{name}</strong>
                              {getEnglishDescription(category) && (
                                <span>{getEnglishDescription(category)}</span>
                              )}
                            </div>
                          </div>
                        </td>

                        <td>
                          <span className="owner-categories-language-badge">
                            {categoryLanguage}
                          </span>
                        </td>

                        <td>
                          <span className="owner-categories-song-count">
                            {songCount !== null && songCount !== undefined
                              ? `${songCount} song${Number(songCount) !== 1 ? "s" : ""}`
                              : "—"}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* PAGINATION */}
            <div className="owner-categories-pagination">
              <div className="owner-categories-pagination-info">
                Showing <strong>{filteredCategories.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}</strong>
                –<strong>{Math.min(currentPage * pageSize, filteredCategories.length)}</strong>
                of <strong>{filteredCategories.length}</strong> categories
              </div>

              <div className="owner-categories-pagination-controls">
                <label className="owner-categories-page-size">
                  Rows per page
                  <select
                    value={pageSize}
                    onChange={(event) => setPageSize(Number(event.target.value))}
                    aria-label="Rows per page"
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                  </select>
                </label>

                <div className="owner-categories-page-buttons">
                  <button type="button" onClick={() => setCurrentPage(1)} disabled={currentPage === 1} aria-label="First page">First</button>
                  <button type="button" onClick={() => setCurrentPage((page) => Math.max(1, page - 1))} disabled={currentPage === 1} aria-label="Previous page">Previous</button>
                  <span className="owner-categories-page-indicator">Page <strong>{currentPage}</strong> of <strong>{totalPages}</strong></span>
                  <button type="button" onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))} disabled={currentPage >= totalPages} aria-label="Next page">Next</button>
                  <button type="button" onClick={() => setCurrentPage(totalPages)} disabled={currentPage >= totalPages} aria-label="Last page">Last</button>
                </div>
              </div>
            </div>

          </section>

        )}

      </main>

    </div>

  );

};


export default BusinessOwnerCategories;
