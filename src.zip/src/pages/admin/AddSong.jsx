
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FaArrowLeft,
  FaCloudUploadAlt,
  FaImage,
  FaMusic,
  FaPlus,
  FaSearch,
  FaSave,
  FaTimes,
} from "react-icons/fa";

import API from "../../services/api";
import "../../assets/css/admin/addSong.css";



/* =====================================================
   LANGUAGES
===================================================== */

const LANGUAGES = [
  { value: "Telugu", nativeName: "తెలుగు" },
  { value: "Hindi", nativeName: "हिन्दी" },
  { value: "English", nativeName: "English" },
  { value: "Malayalam", nativeName: "മലയാളം" },
  { value: "Kannada", nativeName: "ಕನ್ನಡ" },
  { value: "Tamil", nativeName: "தமிழ்" },
];

const LANGUAGE_CONFIG = {
  Telugu: {
    nativeName: "తెలుగు",
    titleLabel: "పాట పేరు",
    titlePlaceholder: "తెలుగు పాట పేరు",
    lyricsPlaceholder: `పల్లవి:
మీ పాట పల్లవి...

చరణం 1:
మొదటి చరణం...

చరణం 2:
రెండవ చరణం...`,
  },
  Hindi: {
    nativeName: "हिन्दी",
    titleLabel: "गीत का नाम",
    titlePlaceholder: "हिन्दी गीत का नाम",
    lyricsPlaceholder: `पल्लवी:
आपके गीत की पल्लवी...

चरण 1:
पहला चरण...

चरण 2:
दूसरा चरण...`,
  },
  English: {
    nativeName: "English",
    titleLabel: "Song Title",
    titlePlaceholder: "Song title",
    lyricsPlaceholder: `Chorus:
Enter the chorus lyrics...

Verse 1:
Enter the first verse...

Verse 2:
Enter the second verse...`,
  },
  Malayalam: {
    nativeName: "മലയാളം",
    titleLabel: "പാട്ടിന്റെ പേര്",
    titlePlaceholder: "മലയാളം പാട്ടിന്റെ പേര്",
    lyricsPlaceholder: `പല്ലവി:
പാട്ടിന്റെ പല്ലവി...

ചരണം 1:
ആദ്യ ചരണം...

ചരണം 2:
രണ്ടാം ചരണം...`,
  },
  Kannada: {
    nativeName: "ಕನ್ನಡ",
    titleLabel: "ಹಾಡಿನ ಹೆಸರು",
    titlePlaceholder: "ಕನ್ನಡ ಹಾಡಿನ ಹೆಸರು",
    lyricsPlaceholder: `ಪಲ್ಲವಿ:
ಹಾಡಿನ ಪಲ್ಲವಿ...

ಚರಣ 1:
ಮೊದಲ ಚರಣ...

ಚರಣ 2:
ಎರಡನೇ ಚರಣ...`,
  },
  Tamil: {
    nativeName: "தமிழ்",
    titleLabel: "பாடல் பெயர்",
    titlePlaceholder: "தமிழ் பாடல் பெயர்",
    lyricsPlaceholder: `பல்லவி:
பாடலின் பல்லவி...

சரணம் 1:
முதல் சரணம்...

சரணம் 2:
இரண்டாவது சரணம்...`,
  },
};

/* =====================================================
   HELPERS
===================================================== */

const normalizeDuplicateValue = (value) =>
  String(value || "")
    .normalize("NFKC")
    .trim()
    .replace(/\s+/g, " ")
    .toLocaleLowerCase();

const getBilingualLabel = (
  english,
  telugu,
  fallback = ""
) => {
  const en = String(english || "").trim();
  const te = String(telugu || "").trim();

  return en && te &&
    normalizeDuplicateValue(en) !== normalizeDuplicateValue(te)
    ? `${en} / ${te}`
    : en || te || fallback;
};

const hasDuplicateBilingualName = (
  items,
  englishValue,
  teluguValue,
  getEnglish,
  getTelugu
) => {
  const en = normalizeDuplicateValue(englishValue);
  const te = normalizeDuplicateValue(teluguValue);

  return items.some((item) => {
    const existingEn = normalizeDuplicateValue(getEnglish(item));
    const existingTe = normalizeDuplicateValue(getTelugu(item));

    return Boolean(
      (en && existingEn === en) ||
      (te && existingTe === te)
    );
  });
};

const initialForm = {
  title: "",
  title_english: "",
  language: "Telugu",
  lyrics: "",
  artist_id: "",
  album_id: "",
  category_id: "",
  ministry_id: "",
};

const extractList = (data, key) => {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.[key])) return data[key];
  return [];
};

/* =====================================================
   SEARCHABLE SINGLE DROPDOWN

   Used for albums, categories and ministries.
===================================================== */

function SearchableDropdown({
  options = [],
  value = "",
  onChange,
  placeholder = "Select an option",
  searchPlaceholder = "Type to search...",
  emptyText = "No matching options found.",
  getLabel,
  getSearchText,
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const rootRef = useRef(null);
  const searchRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        rootRef.current &&
        !rootRef.current.contains(event.target)
      ) {
        setOpen(false);
        setQuery("");
      }
    };

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setOpen(false);
        setQuery("");
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("touchstart", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("touchstart", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  useEffect(() => {
    if (open) {
      requestAnimationFrame(() => searchRef.current?.focus());
    }
  }, [open]);

  const selectedOption = options.find(
    (option) => String(option.id) === String(value)
  );

  const selectedLabel = selectedOption
    ? getLabel(selectedOption)
    : "";

  const normalizedQuery = query.trim().toLocaleLowerCase();

  const visibleOptions = options.filter((option) => {
    if (!normalizedQuery) return true;

    const searchable = getSearchText
      ? getSearchText(option)
      : getLabel(option);

    return String(searchable || "")
      .toLocaleLowerCase()
      .includes(normalizedQuery);
  });

  const chooseOption = (option) => {
    onChange(String(option.id));
    setOpen(false);
    setQuery("");
  };

  return (
    <div
      className={`admin-searchable-dropdown ${
        open ? "is-open" : ""
      }`}
      ref={rootRef}
    >
      <button
        type="button"
        className={`admin-searchable-trigger ${
          open ? "is-open" : ""
        }`}
        onClick={() => setOpen((previous) => !previous)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span
          className={
            selectedLabel ? "has-value" : "is-placeholder"
          }
        >
          {selectedLabel || placeholder}
        </span>

        <span className="admin-searchable-chevron">
          ▾
        </span>
      </button>

      {open && (
        <div className="admin-searchable-menu">
          <div className="admin-searchable-input-wrap">
            <FaSearch />

            <input
              ref={searchRef}
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={searchPlaceholder}
              aria-label={searchPlaceholder}
              onKeyDown={(event) => {
                if (
                  event.key === "Enter" &&
                  visibleOptions.length > 0
                ) {
                  event.preventDefault();
                  chooseOption(visibleOptions[0]);
                }
              }}
            />

            {query && (
              <button
                type="button"
                className="admin-searchable-clear"
                onClick={() => setQuery("")}
                aria-label="Clear search"
              >
                <FaTimes />
              </button>
            )}
          </div>

          <div
            className="admin-searchable-options"
            role="listbox"
          >
            {visibleOptions.length > 0 ? (
              visibleOptions.map((option) => (
                <button
                  type="button"
                  role="option"
                  aria-selected={
                    String(option.id) === String(value)
                  }
                  className={`admin-searchable-option ${
                    String(option.id) === String(value)
                      ? "is-selected"
                      : ""
                  }`}
                  key={option.id}
                  onClick={() => chooseOption(option)}
                >
                  <span>{getLabel(option)}</span>

                  {String(option.id) === String(value) && (
                    <span className="admin-searchable-check">
                      ✓
                    </span>
                  )}
                </button>
              ))
            ) : (
              <div className="admin-searchable-empty">
                {emptyText}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* =====================================================
   MULTIPLE ARTIST DROPDOWN

   Features:
   - Search by English or Telugu name
   - Select multiple artists
   - Remove individual artists
   - Preserve selection order
   - First selected artist is primary artist
===================================================== */

function MultiArtistDropdown({
  options = [],
  selectedIds = [],
  onChange,
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const rootRef = useRef(null);
  const searchRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        rootRef.current &&
        !rootRef.current.contains(event.target)
      ) {
        setOpen(false);
        setQuery("");
      }
    };

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setOpen(false);
        setQuery("");
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("touchstart", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("touchstart", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  useEffect(() => {
    if (open) {
      requestAnimationFrame(() => searchRef.current?.focus());
    }
  }, [open]);

  const selectedArtists = selectedIds
    .map((id) =>
      options.find(
        (artist) => String(artist.id) === String(id)
      )
    )
    .filter(Boolean);

  const normalizedQuery = query.trim().toLocaleLowerCase();

  const filteredOptions = options.filter((artist) => {
    const searchable = [
      artist.name_english,
      artist.name_telugu,
      artist.name,
      artist.bio,
    ]
      .filter(Boolean)
      .join(" ")
      .toLocaleLowerCase();

    return searchable.includes(normalizedQuery);
  });

  const toggleArtist = (artistId) => {
    const id = String(artistId);

    if (selectedIds.includes(id)) {
      onChange(
        selectedIds.filter((selectedId) => selectedId !== id)
      );
    } else {
      onChange([...selectedIds, id]);
    }
  };

  return (
    <div
      className={`admin-multi-artist ${
        open ? "is-open" : ""
      }`}
      ref={rootRef}
    >
      {/* SELECTED ARTISTS */}

      <div className="admin-multi-artist-selected">
        {selectedArtists.length > 0 ? (
          selectedArtists.map((artist, index) => (
            <span
              className="admin-artist-chip"
              key={artist.id}
            >
              <span className="admin-artist-chip-name">
                {getBilingualLabel(
                  artist.name_english,
                  artist.name_telugu || artist.name,
                  "Unnamed Artist"
                )}
              </span>

            <small className="admin-multi-artist-help">
  {selectedIds.length} artist(s) selected.
  This song will be associated with every selected artist.
</small>
              <button
                type="button"
                onClick={() => toggleArtist(artist.id)}
                aria-label={`Remove ${
                  artist.name_english || artist.name
                }`}
              >
                <FaTimes />
              </button>
            </span>
          ))
        ) : (
          <span className="admin-artist-placeholder">
            Select one or more artists
          </span>
        )}
      </div>

      {/* DROPDOWN TRIGGER */}

      <button
        type="button"
        className="admin-searchable-trigger admin-multi-artist-trigger"
        onClick={() => setOpen((previous) => !previous)}
        aria-expanded={open}
      >
        <span>
          {open ? "Close artist list" : "Search and add artists"}
        </span>

        <FaSearch />
      </button>

      {/* DROPDOWN MENU */}

      {open && (
        <div className="admin-searchable-menu">
          <div className="admin-searchable-input-wrap">
            <FaSearch />

            <input
              ref={searchRef}
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search English or Telugu artist names..."
              aria-label="Search artists"
            />

            {query && (
              <button
                type="button"
                className="admin-searchable-clear"
                onClick={() => setQuery("")}
                aria-label="Clear search"
              >
                <FaTimes />
              </button>
            )}
          </div>

          <div className="admin-searchable-options">
            {filteredOptions.length > 0 ? (
              filteredOptions.map((artist) => {
                const id = String(artist.id);
                const selected = selectedIds.includes(id);

                return (
                  <button
                    type="button"
                    key={artist.id}
                    className={`admin-searchable-option ${
                      selected ? "is-selected" : ""
                    }`}
                    onClick={() => toggleArtist(id)}
                  >
                    <span>
                      {getBilingualLabel(
                        artist.name_english,
                        artist.name_telugu || artist.name,
                        "Unnamed Artist"
                      )}
                    </span>

                    <span className="admin-searchable-check">
                      {selected ? "✓" : "+"}
                    </span>
                  </button>
                );
              })
            ) : (
              <div className="admin-searchable-empty">
                No matching artists found.
              </div>
            )}
          </div>
        </div>
      )}

      <small className="admin-multi-artist-help">
  {selectedIds.length} artist(s) selected.
  This song will be associated with every selected artist.
</small>
    </div>
  );
}

/* =====================================================
   DRAG-TO-CROP HELPERS
===================================================== */

const createCroppedImage = (imageSrc, pixelCrop) =>
  new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");
        if (!context) throw new Error("Unable to create image canvas.");

        canvas.width = Math.max(1, Math.round(pixelCrop.width));
        canvas.height = Math.max(1, Math.round(pixelCrop.height));
        context.drawImage(
          image,
          pixelCrop.x,
          pixelCrop.y,
          pixelCrop.width,
          pixelCrop.height,
          0,
          0,
          canvas.width,
          canvas.height
        );
        canvas.toBlob((blob) => {
          if (!blob) {
            reject(new Error("Could not create the cropped image."));
            return;
          }
          resolve(blob);
        }, "image/jpeg", 0.92);
      } catch (error) {
        reject(error);
      }
    };
    image.onerror = () => reject(new Error("Could not load the selected image."));
    image.src = imageSrc;
  });

function DragCropSelector({ imageSrc, onCropComplete }) {
  const imageRef = useRef(null);
  const frameRef = useRef(null);
  const dragRef = useRef(null);
  const [imageSize, setImageSize] = useState({ width: 0, height: 0 });
  const [selection, setSelection] = useState({ x: 10, y: 10, width: 80, height: 80 });

  const getPoint = (event) => {
    const bounds = frameRef.current.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(100, ((event.clientX - bounds.left) / bounds.width) * 100)),
      y: Math.max(0, Math.min(100, ((event.clientY - bounds.top) / bounds.height) * 100)),
    };
  };

  const startDrag = (event, mode) => {
    event.preventDefault();
    event.stopPropagation();
    const point = getPoint(event);
    dragRef.current = { mode, start: point, original: selection };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };

  const moveDrag = (event) => {
    if (!dragRef.current) return;
    const point = getPoint(event);
    const { mode, start, original } = dragRef.current;
    const dx = point.x - start.x;
    const dy = point.y - start.y;
    const minSize = 8;
    let next = { ...original };

    if (mode === "move") {
      next.x = Math.max(0, Math.min(100 - original.width, original.x + dx));
      next.y = Math.max(0, Math.min(100 - original.height, original.y + dy));
    } else {
      if (mode.includes("e")) next.width = Math.max(minSize, Math.min(100 - original.x, original.width + dx));
      if (mode.includes("s")) next.height = Math.max(minSize, Math.min(100 - original.y, original.height + dy));
      if (mode.includes("w")) {
        const right = original.x + original.width;
        next.x = Math.max(0, Math.min(right - minSize, original.x + dx));
        next.width = right - next.x;
      }
      if (mode.includes("n")) {
        const bottom = original.y + original.height;
        next.y = Math.max(0, Math.min(bottom - minSize, original.y + dy));
        next.height = bottom - next.y;
      }
    }
    setSelection(next);
  };

  const endDrag = () => {
    dragRef.current = null;
  };

  const handleImageLoad = (event) => {
    const image = event.currentTarget;
    setImageSize({ width: image.naturalWidth, height: image.naturalHeight });
    setSelection({ x: 10, y: 10, width: 80, height: 80 });
  };

  useEffect(() => {
    if (!imageSize.width || !imageSize.height || !frameRef.current) return;
    const crop = {
      x: (selection.x / 100) * imageSize.width,
      y: (selection.y / 100) * imageSize.height,
      width: (selection.width / 100) * imageSize.width,
      height: (selection.height / 100) * imageSize.height,
    };
    onCropComplete(crop);
  }, [selection, imageSize, onCropComplete]);

  return (
    <div className="admin-drag-crop-stage">
      <div className="admin-drag-crop-frame" ref={frameRef}
        onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag}>
        <img ref={imageRef} src={imageSrc} alt="Crop source" onLoad={handleImageLoad} draggable="false" />
        {imageSize.width > 0 && (
          <div className="admin-drag-crop-selection"
            style={{ left: `${selection.x}%`, top: `${selection.y}%`, width: `${selection.width}%`, height: `${selection.height}%` }}
            onPointerDown={(event) => startDrag(event, "move")}>
            {["nw", "n", "ne", "e", "se", "s", "sw", "w"].map((handle) => (
              <span key={handle} className={`admin-drag-crop-handle handle-${handle}`}
                onPointerDown={(event) => startDrag(event, handle)} />
            ))}
          </div>
        )}
      </div>
      <p className="admin-drag-crop-hint">Drag the box to move it. Drag its corners or edges to resize.</p>
    </div>
  );
}

/* =====================================================
   ADD SONG COMPONENT
===================================================== */

function AddSong() {
  const navigate = useNavigate();

  const [form, setForm] = useState(initialForm);

  // MULTIPLE ARTISTS
  const [selectedArtistIds, setSelectedArtistIds] = useState([]);

  const [audioFile, setAudioFile] = useState(null);
  const [coverFile, setCoverFile] = useState(null);
  const [coverPreview, setCoverPreview] = useState("");

  // COVER CROPPER
  const [cropSource, setCropSource] = useState("");
  const [cropPixels, setCropPixels] = useState(null);
  const [showCropper, setShowCropper] = useState(false);
  const [cropSaving, setCropSaving] = useState(false);

  const [artists, setArtists] = useState([]);
  const [albums, setAlbums] = useState([]);
  const [categories, setCategories] = useState([]);
  const [ministries, setMinistries] = useState([]);

  const [artistsLoading, setArtistsLoading] = useState(true);
  const [albumsLoading, setAlbumsLoading] = useState(true);
  const [categoriesLoading, setCategoriesLoading] = useState(true);
  const [ministriesLoading, setMinistriesLoading] = useState(true);

  const [showArtistForm, setShowArtistForm] = useState(false);
  const [showAlbumForm, setShowAlbumForm] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);

  const [newArtist, setNewArtist] = useState({
    name_english: "",
    name_telugu: "",
    bio: "",
  });

  const [newAlbum, setNewAlbum] = useState({
    title_english: "",
    title_telugu: "",
    release_year: "",
  });

  const [newCategory, setNewCategory] = useState({
    name_english: "",
    name_telugu: "",
  });

  const [pageLoading, setPageLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [quickSaving, setQuickSaving] = useState(false);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const errorRef = useRef(null);

  /* =====================================================
     ERROR AUTO SCROLL
  ===================================================== */

  useEffect(() => {
    if (!error) return;

    const timer = requestAnimationFrame(() => {
      errorRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });

      errorRef.current?.focus({
        preventScroll: true,
      });
    });

    return () => cancelAnimationFrame(timer);
  }, [error]);

  const selectedLanguage =
    LANGUAGE_CONFIG[form.language] || LANGUAGE_CONFIG.Telugu;

  /* =====================================================
     UPDATE MULTIPLE ARTISTS

     Keep the first selected artist in form.artist_id
     for compatibility with existing backend code.
  ===================================================== */

  const handleArtistIdsChange = (artistIds) => {
    setSelectedArtistIds(artistIds);

    setForm((previous) => ({
      ...previous,
      artist_id: artistIds[0] || "",
    }));
  };

  /* =====================================================
     LOAD ENTITY DATA INDEPENDENTLY
  ===================================================== */

  useEffect(() => {
    let cancelled = false;

    const loadOne = async (
      endpoint,
      key,
      setter,
      setLoading,
      label
    ) => {
      try {
        const response = await API.get(endpoint);

        if (!cancelled) {
          setter(extractList(response.data, key));
        }
      } catch (err) {
        console.error(`Failed to load ${label}:`, err);

        if (!cancelled) {
          setter([]);

          setError((previous) =>
            previous
              ? `${previous} ${label} could not be loaded.`
              : `${label} could not be loaded. Other fields remain available.`
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    const requests = [
      loadOne(
        "/artists",
        "artists",
        setArtists,
        setArtistsLoading,
        "Artists"
      ),

      loadOne(
        "/albums",
        "albums",
        setAlbums,
        setAlbumsLoading,
        "Albums"
      ),

      loadOne(
        "/categories",
        "categories",
        setCategories,
        setCategoriesLoading,
        "Categories"
      ),

      loadOne(
        "/ministries",
        "ministries",
        setMinistries,
        setMinistriesLoading,
        "Ministries"
      ),
    ];

    Promise.all(requests).finally(() => {
      if (!cancelled) {
        setPageLoading(false);
      }
    });

    return () => {
      cancelled = true;
    };
  }, []);

  /* =====================================================
     SORT DROPDOWN OPTIONS
  ===================================================== */

  const sortAndSearch = (items, searchText, getLabel) => {
    const query = searchText.trim().toLocaleLowerCase();

    return [...items]
      .filter((item) =>
        String(getLabel(item) || "")
          .toLocaleLowerCase()
          .includes(query)
      )
      .sort((a, b) =>
        String(getLabel(a) || "").localeCompare(
          String(getLabel(b) || ""),
          undefined,
          {
            sensitivity: "base",
            numeric: true,
          }
        )
      );
  };

  const filteredArtists = sortAndSearch(
    artists,
    "",
    (artist) =>
      getBilingualLabel(
        artist.name_english,
        artist.name_telugu || artist.name,
        "Unnamed Artist"
      )
  );

  const filteredAlbums = sortAndSearch(
    albums,
    "",
    (album) =>
      getBilingualLabel(
        album.title_english,
        album.title_telugu || album.title,
        "Untitled Album"
      )
  );

  const filteredCategories = sortAndSearch(
    categories,
    "",
    (category) =>
      category.name_english ||
      category.name ||
      category.name_telugu ||
      ""
  );

  const filteredMinistries = sortAndSearch(
    ministries,
    "",
    (ministry) =>
      ministry.name_english ||
      ministry.name ||
      ministry.name_telugu ||
      ""
  );

  /* =====================================================
     LANGUAGE CHANGE
  ===================================================== */

  const handleLanguageChange = (event) => {
    const language = event.target.value;

    setForm((previous) => ({
      ...previous,
      language,
    }));

    setError("");
    setSuccess("");

    setShowArtistForm(false);
    setShowAlbumForm(false);
    setShowCategoryForm(false);
  };

  /* =====================================================
     COVER PREVIEW CLEANUP
  ===================================================== */

  useEffect(() => {
    return () => {
      if (coverPreview) {
        URL.revokeObjectURL(coverPreview);
      }
    };
  }, [coverPreview]);

  useEffect(() => {
    return () => {
      if (cropSource) URL.revokeObjectURL(cropSource);
    };
  }, [cropSource]);

  /* =====================================================
     MINISTRY CHANGE
  ===================================================== */

  const handleMinistryChangeValue = (ministryId) => {
    setForm((previous) => ({
      ...previous,
      ministry_id: ministryId,
    }));
  };

  /* =====================================================
     CREATE ARTIST

     Automatically select the new artist.
     Preserve all previously selected artists.
  ===================================================== */

  const createArtist = async () => {
    const nameEnglish = newArtist.name_english.trim();
    const nameTelugu = newArtist.name_telugu.trim();

    if (!nameEnglish || !nameTelugu) {
      setError(
        "Please enter both English and Telugu artist names."
      );
      return;
    }

    if (
      hasDuplicateBilingualName(
        artists,
        nameEnglish,
        nameTelugu,
        (x) => x.name_english,
        (x) => x.name_telugu || x.name
      )
    ) {
      setError(
        "This English or Telugu artist name already exists. Please choose a unique name."
      );
      return;
    }

    try {
      setQuickSaving(true);
      setError("");
      setSuccess("");
      const response = await API.post("/admin/artists", {
        name: nameTelugu,
        name_english: nameEnglish,
        name_telugu: nameTelugu,
        bio: newArtist.bio.trim(),
        language: form.language,
      });

      const artist = response.data?.artist;

      if (!artist?.id) {
        throw new Error(
          "Artist was not returned by server."
        );
      }

      setArtists((previous) => [...previous, artist]);

      // Automatically select the new artist
      setSelectedArtistIds((previous) => {
        const updated = [
          ...previous,
          String(artist.id),
        ];

        setForm((current) => ({
          ...current,
          artist_id: updated[0] || "",
        }));

        return updated;
      });

      setNewArtist({
        name_english: "",
        name_telugu: "",
        bio: "",
      });

      setShowArtistForm(false);

      setSuccess(
        `Artist "${nameEnglish} / ${nameTelugu}" added and selected successfully.`
      );
    } catch (err) {
      console.error("Create artist error:", err);

      setError(
        err.response?.data?.message ||
        err.message ||
        "Unable to create artist."
      );
    } finally {
      setQuickSaving(false);
    }
  };

  /* =====================================================
     CREATE ALBUM
  ===================================================== */

  const createAlbum = async () => {
    const titleEnglish = newAlbum.title_english.trim();
    const titleTelugu = newAlbum.title_telugu.trim();

    if (!titleEnglish || !titleTelugu) {
      setError(
        "Please enter both English and Telugu album titles."
      );
      return;
    }

    if (
      hasDuplicateBilingualName(
        albums,
        titleEnglish,
        titleTelugu,
        (x) => x.title_english,
        (x) => x.title_telugu || x.title
      )
    ) {
      setError(
        "This English or Telugu album title already exists. Please choose a unique title."
      );
      return;
    }

    try {
      setQuickSaving(true);
      setError("");
      setSuccess("");

      const response = await API.post("/admin/albums", {
        title: titleTelugu,
        title_english: titleEnglish,
        title_telugu: titleTelugu,
        artist_id: null,
        release_year: newAlbum.release_year
          ? Number(newAlbum.release_year)
          : null,
        language: form.language,
      });

      const album = response.data?.album;

      if (!album?.id) {
        throw new Error(
          "Album was not returned by server. Check the album API response."
        );
      }

      setAlbums((previous) => [...previous, album]);

      setForm((previous) => ({
        ...previous,
        album_id: String(album.id),
      }));

      setNewAlbum({
        title_english: "",
        title_telugu: "",
        release_year: "",
      });

      setShowAlbumForm(false);

      setSuccess(
        `Album "${titleEnglish} / ${titleTelugu}" added successfully.`
      );
    } catch (err) {
      console.error("Create album error:", err);

      setError(
        err.response?.data?.message ||
        err.message ||
        "Unable to create album."
      );
    } finally {
      setQuickSaving(false);
    }
  };

  /* =====================================================
     CREATE CATEGORY
  ===================================================== */

  const createCategory = async () => {
    const nameEnglish = newCategory.name_english.trim();
    const nameTelugu = newCategory.name_telugu.trim();

    if (!nameEnglish || !nameTelugu) {
      setError(
        "Please enter both English and Telugu category names."
      );
      return;
    }

    if (
      hasDuplicateBilingualName(
        categories,
        nameEnglish,
        nameTelugu,
        (x) => x.name_english,
        (x) => x.name_telugu || x.name
      )
    ) {
      setError(
        "This English or Telugu category name already exists. Please choose a unique name."
      );
      return;
    }

    try {
      setQuickSaving(true);
      setError("");
      setSuccess("");

      const response = await API.post("/admin/categories", {
        name: nameTelugu,
        name_english: nameEnglish,
        name_telugu: nameTelugu,
        language: form.language,
      });

      const category = response.data?.category;

      if (!category?.id) {
        throw new Error(
          "Category was not returned by server."
        );
      }

      setCategories((previous) => [
        ...previous,
        category,
      ]);

      setForm((previous) => ({
        ...previous,
        category_id: String(category.id),
      }));

      setNewCategory({
        name_english: "",
        name_telugu: "",
      });

      setShowCategoryForm(false);

      setSuccess(
        `Category "${nameEnglish} / ${nameTelugu}" added successfully.`
      );
    } catch (err) {
      console.error("Create category error:", err);

      setError(
        err.response?.data?.message ||
        err.message ||
        "Unable to create category."
      );
    } finally {
      setQuickSaving(false);
    }
  };

  /* =====================================================
     AUDIO FILE
  ===================================================== */

  const handleAudioChange = (event) => {
    const file = event.target.files?.[0];

    if (!file) {
      setAudioFile(null);
      return;
    }

    const fileName = file.name.toLowerCase();

    const validExtension = /\.(mp3|m4a|mp4)$/i.test(
      fileName
    );

    const allowedTypes = [
      "audio/mpeg",
      "audio/mp3",
      "audio/mp4",
      "audio/x-m4a",
      "application/octet-stream",
    ];

    if (!validExtension || !allowedTypes.includes(file.type)) {
      setError(
        "Please select a valid MP3, M4A or audio MP4 file."
      );

      setAudioFile(null);
      event.target.value = "";
      return;
    }

    if (file.size === 0) {
      setError("The selected audio file is empty.");
      setAudioFile(null);
      event.target.value = "";
      return;
    }

    if (file.size > 30 * 1024 * 1024) {
      setError(
        "Audio file must be smaller than 30 MB."
      );

      setAudioFile(null);
      event.target.value = "";
      return;
    }

    setAudioFile(file);
    setError("");
  };

  const removeAudio = () => {
    setAudioFile(null);

    const input = document.getElementById(
      "song-audio-input"
    );

    if (input) input.value = "";
  };

  /* =====================================================
     NORMAL FIELD CHANGE
  ===================================================== */

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  /* =====================================================
     COVER FILE + CROPPER
  ===================================================== */

  const handleCoverChange = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
      setError("Cover image must be JPG, PNG or WebP.");
      event.target.value = "";
      return;
    }
    if (!file.size) {
      setError("The selected cover image is empty.");
      event.target.value = "";
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("Cover image must be smaller than 10 MB.");
      event.target.value = "";
      return;
    }

    const sourceUrl = URL.createObjectURL(file);
    setCropSource(sourceUrl);
    setCropPixels(null);
    setShowCropper(true);
    setError("");
  };

  const handleCropComplete = (croppedAreaPixels) => {
    setCropPixels(croppedAreaPixels);
  };

  const closeCropper = () => {
    setShowCropper(false);
    if (cropSource) URL.revokeObjectURL(cropSource);
    setCropSource("");
    const input = document.getElementById("song-cover-input");
    if (input) input.value = "";
  };

  const applyCrop = async () => {
    if (!cropSource || !cropPixels) {
      setError("Please adjust the crop area before applying.");
      return;
    }

    try {
      setCropSaving(true);
      const croppedBlob = await createCroppedImage(
        cropSource,
        cropPixels
      );
      const croppedFile = new File(
        [croppedBlob],
        `keerthana-cover-${Date.now()}.jpg`,
        { type: "image/jpeg", lastModified: Date.now() }
      );

      setCoverFile(croppedFile);
      setCoverPreview((previous) => {
        if (previous) URL.revokeObjectURL(previous);
        return URL.createObjectURL(croppedFile);
      });
      closeCropper();
      setError("");
    } catch (err) {
      console.error("Cover crop error:", err);
      setError(err.message || "Unable to crop the cover image.");
    } finally {
      setCropSaving(false);
    }
  };

  const removeCover = () => {
    setCoverFile(null);
    if (coverPreview) URL.revokeObjectURL(coverPreview);
    setCoverPreview("");
    const input = document.getElementById("song-cover-input");
    if (input) input.value = "";
  };

  /* =====================================================
     FILE SIZE
  ===================================================== */

  const formatFileSize = (bytes) => {
    if (!bytes) return "0 MB";

    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  /* =====================================================
     SUBMIT SONG

     Multiple artists are submitted as artist_ids.
     First artist is also sent as artist_id.
  ===================================================== */

  const handleSubmit = async (event) => {
    event.preventDefault();

    setError("");
    setSuccess("");

    if (
      !LANGUAGES.some(
        (language) => language.value === form.language
      )
    ) {
      setError("Please select a valid song language.");
      return;
    }

    if (!form.title.trim()) {
      setError(
        `${selectedLanguage.titleLabel} is required.`
      );
      return;
    }

    // MULTIPLE ARTIST VALIDATION
    if (selectedArtistIds.length === 0) {
      setError(
        "Please select at least one artist."
      );
      return;
    }

    if (!form.category_id) {
      setError("Category is required. Please select or create a category.");
      return;
    }

    if (!audioFile) {
      setError(
        "Audio file is required. Please select an audio file."
      );
      return;
    }

    try {
      setSaving(true);

      const formData = new FormData();

      formData.append("title", form.title.trim());
      formData.append(
        "title_english",
        form.title_english.trim()
      );

      formData.append("language", form.language);
      formData.append("lyrics", form.lyrics);

      // Primary artist: first selected artist
      formData.append(
        "artist_id",
        selectedArtistIds[0]
      );

      // All selected artists
      formData.append(
        "artist_ids",
        JSON.stringify(selectedArtistIds)
      );

      formData.append(
        "category_id",
        form.category_id
      );

      if (form.album_id) {
        formData.append(
          "album_id",
          form.album_id
        );
      }

      if (form.ministry_id) {
        formData.append(
          "ministry_id",
          form.ministry_id
        );
      }

      formData.append("audio", audioFile);

      if (coverFile) {
        formData.append("cover", coverFile);
      }

      const response = await API.post(
        "/admin/songs",
        formData
      );

      if (response.data?.success === false) {
        throw new Error(
          response.data?.message ||
          "Song upload failed."
        );
      }

      setSuccess("Song uploaded successfully!");

      setTimeout(() => {
        navigate("/admin/songs");
      }, 1000);

    } catch (err) {
      console.error("Song upload error:", err);

      setError(
        err.response?.data?.message ||
        err.message ||
        "Unable to upload song."
      );
    } finally {
      setSaving(false);
    }
  };

  /* =====================================================
     PAGE LOADING
  ===================================================== */

  if (pageLoading) {
    return (
      <div className="admin-page">
        <div className="admin-loading">
          Loading Add Song...
        </div>
      </div>
    );
  }

  /* =====================================================
     PAGE
  ===================================================== */

  return (
    <div className="admin-page">

      {/* HEADER */}

      <div className="admin-form-header">
        <button
          type="button"
          className="admin-back-button"
          onClick={() => navigate("/admin/songs")}
        >
          <FaArrowLeft />
          Back
        </button>

        <div>
          <span>KEERTHANA ADMIN</span>

          <h1>Add New Song</h1>

          <p>
            Add the song, multiple artists, album, category,
            ministry, audio and lyrics from one page.
          </p>
        </div>
      </div>

      {/* ERROR */}

      {error && (
        <div
          ref={errorRef}
          className="admin-error"
          role="alert"
          aria-live="assertive"
          tabIndex={-1}
        >
          {error}
        </div>
      )}

      {/* SUCCESS */}

      {success && (
        <div className="admin-success">
          {success}
        </div>
      )}

      <form
        className="admin-song-form"
        onSubmit={handleSubmit}
      >

        {/* =================================================
            SONG INFORMATION
        ================================================= */}

        <div className="admin-form-section">

          <div className="admin-form-section-title">
            <h2>Song Information</h2>
            <p>Enter the basic details of the song.</p>
          </div>

          <div className="admin-form-grid">

            {/* LANGUAGE */}

            <div className="admin-field">
              <label>Song Language</label>

              <select
                name="language"
                value={form.language}
                onChange={handleLanguageChange}
                required
              >
                {LANGUAGES.map((language) => (
                  <option
                    key={language.value}
                    value={language.value}
                  >
                    {language.nativeName}
                  </option>
                ))}
              </select>

              <small>
                Selected language: {selectedLanguage.nativeName}
              </small>
            </div>

            {/* SONG TITLE */}

            <div className="admin-field">
              <label>
                {selectedLanguage.titleLabel} *
              </label>

              <input
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                placeholder={selectedLanguage.titlePlaceholder}
                maxLength={255}
                required
              />
            </div>

            {/* ENGLISH TITLE */}

            <div className="admin-field">
              <label>English Title</label>

              <input
                type="text"
                name="title_english"
                value={form.title_english}
                onChange={handleChange}
                placeholder="English title"
                maxLength={255}
              />
            </div>

            {/* MULTIPLE ARTISTS */}

            <div className="admin-field admin-multiple-artists-field">

              <div className="admin-field-label-row">
                <label>
                  Artists *
                </label>

                <button
                  type="button"
                  className="admin-inline-add-button"
                  onClick={() => {
                    setError("");
                    setSuccess("");

                    setShowArtistForm((previous) => !previous);
                    setShowAlbumForm(false);
                    setShowCategoryForm(false);
                  }}
                >
                  <FaPlus />
                  New Artist
                </button>
              </div>

              <MultiArtistDropdown
                options={filteredArtists}
                selectedIds={selectedArtistIds}
                onChange={handleArtistIdsChange}
              />

              {artistsLoading && (
                <small>Loading artists...</small>
              )}

              {!artistsLoading &&
                filteredArtists.length === 0 && (
                  <small>
                    No artists available. Please create an artist.
                  </small>
                )}

              {/* QUICK CREATE ARTIST */}

              {showArtistForm && (
                <div className="admin-quick-create">

                  <h4>Add New Artist</h4>

                  <input
                    type="text"
                    placeholder="Artist name (English) *"
                    value={newArtist.name_english}
                    onChange={(event) =>
                      setNewArtist((previous) => ({
                        ...previous,
                        name_english: event.target.value,
                      }))
                    }
                  />

                  <input
                    type="text"
                    placeholder="కళాకారుడి పేరు (తెలుగు) *"
                    value={newArtist.name_telugu}
                    onChange={(event) =>
                      setNewArtist((previous) => ({
                        ...previous,
                        name_telugu: event.target.value,
                      }))
                    }
                  />

                  <textarea
                    rows="3"
                    placeholder="Artist bio (optional)"
                    value={newArtist.bio}
                    onChange={(event) =>
                      setNewArtist((previous) => ({
                        ...previous,
                        bio: event.target.value,
                      }))
                    }
                  />

                  <div className="admin-quick-actions">

                    <button
                      type="button"
                      disabled={quickSaving}
                      onClick={() => setShowArtistForm(false)}
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      className="admin-primary-button"
                      disabled={quickSaving}
                      onClick={createArtist}
                    >
                      <FaPlus />

                      {quickSaving
                        ? "Adding..."
                        : "Add Artist"}
                    </button>

                  </div>
                </div>
              )}

            </div>

            {/* ALBUM */}

            <div className="admin-field">

              <div className="admin-field-label-row">
                <label>Album</label>

                <button
                  type="button"
                  className="admin-inline-add-button"
                  onClick={() => {
                    setError("");
                    setSuccess("");

                    setShowAlbumForm((previous) => !previous);
                    setShowArtistForm(false);
                    setShowCategoryForm(false);
                  }}
                >
                  <FaPlus />
                  New Album
                </button>
              </div>

              <SearchableDropdown
                options={filteredAlbums}
                value={form.album_id}
                onChange={(value) =>
                  setForm((previous) => ({
                    ...previous,
                    album_id: value,
                  }))
                }
                placeholder="No Album / Single"
                searchPlaceholder="Search albums..."
                emptyText="No matching albums found."
                getLabel={(album) =>
                  getBilingualLabel(
                    album.title_english,
                    album.title_telugu || album.title,
                    "Untitled Album"
                  )
                }
                getSearchText={(album) =>
                  [
                    album.title_english,
                    album.title,
                    album.title_telugu,
                    album.artist_name_english,
                    album.artist_name,
                    album.artist_name_telugu,
                  ]
                    .filter(Boolean)
                    .join(" ")
                }
              />

              {albumsLoading && (
                <small>Loading albums...</small>
              )}

              <small>
                Album is optional. Select any album or leave this as
                No Album / Single.
              </small>

              {showAlbumForm && (
                <div className="admin-quick-create">

                  <h4>Add New Album</h4>

                  <input
                    type="text"
                    placeholder="Album title (English) *"
                    value={newAlbum.title_english}
                    onChange={(event) =>
                      setNewAlbum((previous) => ({
                        ...previous,
                        title_english: event.target.value,
                      }))
                    }
                  />

                  <input
                    type="text"
                    placeholder="ఆల్బమ్ పేరు (తెలుగు) *"
                    value={newAlbum.title_telugu}
                    onChange={(event) =>
                      setNewAlbum((previous) => ({
                        ...previous,
                        title_telugu: event.target.value,
                      }))
                    }
                  />

                  <input
                    type="number"
                    min="1900"
                    max="2100"
                    placeholder="Release year (optional)"
                    value={newAlbum.release_year}
                    onChange={(event) =>
                      setNewAlbum((previous) => ({
                        ...previous,
                        release_year: event.target.value,
                      }))
                    }
                  />

                  <small>
                    Creating an album without an artist requires
                    backend and database support for a NULL artist_id.
                  </small>

                  <div className="admin-quick-actions">

                    <button
                      type="button"
                      disabled={quickSaving}
                      onClick={() => setShowAlbumForm(false)}
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      className="admin-primary-button"
                      disabled={quickSaving}
                      onClick={createAlbum}
                    >
                      <FaPlus />

                      {quickSaving
                        ? "Adding..."
                        : "Add Album"}
                    </button>

                  </div>
                </div>
              )}

            </div>

            {/* CATEGORY */}

            <div className="admin-field">

              <div className="admin-field-label-row">
                <label>Category *</label>

                <button
                  type="button"
                  className="admin-inline-add-button"
                  onClick={() => {
                    setError("");
                    setSuccess("");

                    setShowCategoryForm((previous) => !previous);
                    setShowArtistForm(false);
                    setShowAlbumForm(false);
                  }}
                >
                  <FaPlus />
                  New Category
                </button>
              </div>

              <SearchableDropdown
                options={filteredCategories}
                value={form.category_id}
                onChange={(value) =>
                  setForm((previous) => ({
                    ...previous,
                    category_id: value,
                  }))
                }
                placeholder="Select Category"
                searchPlaceholder="Search categories..."
                emptyText="No categories found. Please create a category."
                getLabel={(category) =>
                  getBilingualLabel(
                    category.name_english,
                    category.name_telugu || category.name,
                    "Unnamed Category"
                  )
                }
                getSearchText={(category) =>
                  [
                    category.name_english,
                    category.name,
                    category.name_telugu,
                  ]
                    .filter(Boolean)
                    .join(" ")
                }
              />

              {categoriesLoading && (
                <small>Loading categories...</small>
              )}

              {!categoriesLoading &&
                filteredCategories.length === 0 && (
                  <small>
                    No categories available. Please create a category.
                  </small>
                )}

              {showCategoryForm && (
                <div className="admin-quick-create">

                  <h4>Add New Category</h4>

                  <input
                    type="text"
                    placeholder="Category name (English) *"
                    value={newCategory.name_english}
                    onChange={(event) =>
                      setNewCategory((previous) => ({
                        ...previous,
                        name_english: event.target.value,
                      }))
                    }
                  />

                  <input
                    type="text"
                    placeholder="వర్గం పేరు (తెలుగు) *"
                    value={newCategory.name_telugu}
                    onChange={(event) =>
                      setNewCategory((previous) => ({
                        ...previous,
                        name_telugu: event.target.value,
                      }))
                    }
                  />

                  <div className="admin-quick-actions">

                    <button
                      type="button"
                      disabled={quickSaving}
                      onClick={() => setShowCategoryForm(false)}
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      className="admin-primary-button"
                      disabled={quickSaving}
                      onClick={createCategory}
                    >
                      <FaPlus />

                      {quickSaving
                        ? "Adding..."
                        : "Add Category"}
                    </button>

                  </div>
                </div>
              )}

            </div>

            {/* MINISTRY */}

            <div className="admin-field">

              <div className="admin-field-label-row">
                <label>Ministry</label>
              </div>

              <SearchableDropdown
                options={filteredMinistries}
                value={form.ministry_id}
                onChange={handleMinistryChangeValue}
                placeholder="Select Ministry (Optional)"
                searchPlaceholder="Search ministries..."
                emptyText="No matching ministries found."
                getLabel={(ministry) =>
                  getBilingualLabel(
                    ministry.name_english,
                    ministry.name_telugu || ministry.name,
                    "Unnamed Ministry"
                  )
                }
                getSearchText={(ministry) =>
                  [
                    ministry.name_english,
                    ministry.name,
                    ministry.name_telugu,
                    ministry.description,
                    ministry.language,
                  ]
                    .filter(Boolean)
                    .join(" ")
                }
              />

              {ministriesLoading && (
                <small>Loading ministries...</small>
              )}

            </div>

          </div>
        </div>

        {/* =================================================
            MEDIA
        ================================================= */}

        <div className="admin-form-section">

          <div className="admin-form-section-title">
            <h2>Media</h2>
            <p>Upload the song audio and cover artwork.</p>
          </div>

          <div className="admin-upload-grid">

            {/* AUDIO */}

            <div className="admin-upload-box">

              <div className="admin-upload-icon">
                <FaMusic />
              </div>

              <h3>Audio File *</h3>

              <p>
                MP3, M4A or MP4 Audio, maximum 30 MB
              </p>

              {!audioFile ? (
                <>
                  <input
                    id="song-audio-input"
                    className="admin-file-input"
                    type="file"
                    accept=".mp3,.m4a,.mp4,audio/mpeg,audio/mp4"
                    onChange={handleAudioChange}
                  />

                  <label
                    htmlFor="song-audio-input"
                    className="admin-upload-button"
                  >
                    <FaCloudUploadAlt />
                    Choose Audio
                  </label>
                </>
              ) : (
                <div className="admin-selected-file">

                  <div>
                    <strong>{audioFile.name}</strong>

                    <span>
                      {formatFileSize(audioFile.size)}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={removeAudio}
                    aria-label="Remove audio"
                  >
                    <FaTimes />
                  </button>

                </div>
              )}

            </div>

            {/* COVER */}

            <div className="admin-upload-box">

              {!coverPreview ? (
                <div className="admin-upload-icon">
                  <FaImage />
                </div>
              ) : (
                <img
                  className="admin-cover-preview"
                  src={coverPreview}
                  alt="Song cover preview"
                />
              )}

              <h3>Cover Image</h3>

              <p>
                JPG, PNG or WebP, maximum 10 MB
              </p>

              <input
                id="song-cover-input"
                className="admin-file-input"
                type="file"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                onChange={handleCoverChange}
              />

              <div className="admin-cover-actions">
                <label
                  htmlFor="song-cover-input"
                  className="admin-upload-button"
                >
                  <FaCloudUploadAlt />
                  {coverFile ? "Change Cover Image" : "Choose Cover Image"}
                </label>

                {coverFile && (
                  <button
                    type="button"
                    className="admin-cover-remove-button"
                    onClick={removeCover}
                    aria-label="Remove cover"
                  >
                    <FaTimes /> Remove
                  </button>
                )}
              </div>

              {coverFile && (
                <small>
                  Cropped image: {formatFileSize(coverFile.size)}
                </small>
              )}

            </div>

          </div>
        </div>

        {/* =================================================
            LYRICS
        ================================================= */}

        <div className="admin-form-section">

          <div className="admin-form-section-title">
            <h2>
              Lyrics — {selectedLanguage.nativeName}
            </h2>

            <p>
              Enter the lyrics in the selected song language.
            </p>
          </div>

          <div className="admin-field">

            <textarea
              name="lyrics"
              value={form.lyrics}
              onChange={handleChange}
              rows="16"
              placeholder={selectedLanguage.lyricsPlaceholder}
            />

          </div>
        </div>

        {/* =================================================
            ACTIONS
        ================================================= */}

        <div className="admin-form-actions">

          <button
            type="button"
            className="admin-cancel-button"
            disabled={saving || quickSaving}
            onClick={() => navigate("/admin/songs")}
          >
            Cancel
          </button>

          <button
            type="submit"
            className="admin-primary-button"
            disabled={saving || quickSaving}
          >
            <FaSave />

            {saving ? "Uploading..." : "Save Song"}
          </button>

        </div>

        {showCropper && cropSource && (
          <div className="admin-cropper-backdrop" role="presentation">
            <section
              className="admin-cropper-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="admin-cropper-title"
            >
              <header className="admin-cropper-header">
                <div>
                  <h2 id="admin-cropper-title">Crop Cover Image</h2>
                  <p>Drag the selection box and its handles to choose only the part you want.</p>
                </div>
                <button type="button" onClick={closeCropper} aria-label="Close cropper">
                  <FaTimes />
                </button>
              </header>

              <div className="admin-cropper-area admin-cropper-area-selection">
                <DragCropSelector
                  imageSrc={cropSource}
                  onCropComplete={handleCropComplete}
                />
              </div>

              <footer className="admin-cropper-footer">
                <button type="button" className="admin-cropper-cancel" onClick={closeCropper} disabled={cropSaving}>Cancel</button>
                <button type="button" className="admin-cropper-apply" onClick={applyCrop} disabled={cropSaving || !cropPixels}>
                  {cropSaving ? "Applying..." : "Apply Crop"}
                </button>
              </footer>
            </section>
          </div>
        )}

      </form>
    </div>
  );
}

export default AddSong;
