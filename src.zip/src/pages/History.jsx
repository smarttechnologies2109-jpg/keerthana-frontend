
import { useCallback, useEffect, useState } from "react";

import {
  FaClock,
  FaHistory,
  FaPlay,
  FaPause,
  FaTrash,
  FaMusic,
  FaSearch,
  FaTimes,
} from "react-icons/fa";

import API from "../services/api";
import { usePlayer } from "../context/PlayerContext";
import { getMediaUrl } from "../utils/media";
import VoiceSearch from "../components/VoiceSearch";

import "../assets/css/history.css";

/* =========================================================
   KEERTHANA — LISTENING HISTORY
========================================================= */



/* =========================================================
   HELPERS
========================================================= */

const getSongId = (song) =>
  song?.id ?? song?.song_id ?? song?.songId ?? null;

const getSongTitle = (song) =>
  String(
    song?.title_english ||
    song?.english_title ||
    song?.title ||
    song?.name ||
    "Untitled Song"
  ).trim();

const getSongTeluguTitle = (song) => {
  const englishTitle = getSongTitle(song);
  const teluguTitle =
    song?.title_telugu ||
    song?.telugu_title ||
    song?.title_native ||
    song?.title ||
    "";

  const cleanedTitle = String(teluguTitle).trim();

  return cleanedTitle &&
    cleanedTitle.toLowerCase() !== englishTitle.toLowerCase()
    ? cleanedTitle
    : "";
};

/*
 * Artist names are displayed in English.
 * Prefer English fields on the history song, then resolve artist_id
 * against the /artists API response (same approach as AllSongs.jsx).
 */
const containsTelugu = (value) =>
  /[\u0C00-\u0C7F]/.test(String(value || ""));

const firstEnglishName = (...values) => {
  for (const value of values) {
    if (typeof value !== "string") continue;

    const name = value.trim();
    if (!name || containsTelugu(name)) continue;
    if (["unknown artist", "null", "undefined", "n/a"].includes(name.toLowerCase())) continue;

    return name;
  }

  return "";
};

const getArtistNames = (song, artistsById = {}) => {
  const names = [];
  const addName = (value) => {
    if (typeof value !== "string") return;
    // Some APIs return all singers in one comma-separated field.
    value.split(",").forEach((part) => {
      const name = firstEnglishName(part);
      if (
        name &&
        !names.some((existing) => existing.toLowerCase() === name.toLowerCase())
      ) {
        names.push(name);
      }
    });
  };

  const addArtist = (artist) => {
    if (typeof artist === "string") {
      // A string can be an artist name or an artist ID.
      const linked = artistsById[String(artist)];
      if (linked) {
        addName(linked.name_english);
        addName(linked.english_name);
        addName(linked.nameEnglish);
        addName(linked.name);
      } else if (!/^\d+$/.test(artist.trim())) {
        addName(artist);
      }
      return;
    }

    if (!artist || typeof artist !== "object") return;
    const id = artist.id ?? artist.artist_id ?? artist.artistId;
    const linked = id != null ? artistsById[String(id)] : null;

    [
      artist.name_english,
      artist.english_name,
      artist.nameEnglish,
      artist.englishName,
      artist.artist_name_english,
      artist.artist_english,
      artist.artist_name_en,
      artist.name_en,
      artist.name,
      linked?.name_english,
      linked?.english_name,
      linked?.nameEnglish,
      linked?.englishName,
      linked?.artist_name_english,
      linked?.name,
    ].forEach(addName);
  };

  const artistEntries = [
    ...(Array.isArray(song?.artists) ? song.artists : song?.artists ? [song.artists] : []),
    ...(Array.isArray(song?.song_artists) ? song.song_artists : []),
    ...(Array.isArray(song?.artist) ? song.artist : []),
  ];
  artistEntries.forEach(addArtist);

  const ids = [
    ...(Array.isArray(song?.artist_ids) ? song.artist_ids : []),
    ...(Array.isArray(song?.artistIds) ? song.artistIds : []),
    ...(Array.isArray(song?.song_artists)
      ? song.song_artists.map((entry) => entry?.artist_id ?? entry?.artistId ?? entry?.id).filter(Boolean)
      : []),
  ];
  ids.forEach((id) => {
    const linked = id != null ? artistsById[String(id)] : null;
    if (linked) addArtist(linked);
  });

  const singleArtistId =
    song?.artist_id ??
    song?.artistId ??
    (song?.artist && !Array.isArray(song.artist) ? song.artist.id ?? song.artist.artist_id : null) ??
    song?.artist_details?.id ??
    song?.artistDetails?.id;

  if (singleArtistId != null) {
    addArtist(artistsById[String(singleArtistId)] || { id: singleArtistId });
  }

  const artistObject =
    song?.artist && typeof song.artist === "object" && !Array.isArray(song.artist)
      ? song.artist
      : {};
  const nestedArtist =
    song?.artist_details && typeof song.artist_details === "object"
      ? song.artist_details
      : song?.artistDetails && typeof song.artistDetails === "object"
        ? song.artistDetails
        : {};

  [
    song?.artist_name_english,
    song?.artist_english,
    song?.artist_english_name,
    song?.artist_name_en,
    song?.artistEnglishName,
    song?.artistNameEnglish,
    song?.artistEnglish,
    artistObject.name_english,
    artistObject.english_name,
    artistObject.nameEnglish,
    artistObject.name,
    nestedArtist.name_english,
    nestedArtist.english_name,
    nestedArtist.nameEnglish,
    nestedArtist.name,
    song?.artist_name,
    song?.artistName,
    typeof song?.artist === "string" ? song.artist : "",
  ].forEach(addName);

  return names.join(", ") || "Artist name unavailable";
};

const getAlbumName = (song) =>
  song?.album_name ||
  song?.album?.title ||
  (typeof song?.album === "string"
    ? song.album
    : "Single");

const formatPlayedDate = (value) => {
  if (!value) return "Recently played";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Recently played";
  }

  const now = new Date();

  const today = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate()
  );

  const playedDay = new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate()
  );

  const days = Math.round(
    (today.getTime() - playedDay.getTime()) / 86400000
  );

  if (days === 0) {
    return `Today, ${date.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    })}`;
  }

  if (days === 1) {
    return "Yesterday";
  }

  return date.toLocaleDateString([], {
    day: "numeric",
    month: "short",
    year:
      date.getFullYear() !== now.getFullYear()
        ? "numeric"
        : undefined,
  });
};

const normalizeHistory = (responseData) => {
  const records = Array.isArray(responseData)
    ? responseData
    : responseData?.history ||
      responseData?.songs ||
      responseData?.recently_played ||
      responseData?.data ||
      [];

  if (!Array.isArray(records)) return [];

  const seen = new Set();

  return records
    .map((record) => {
      const song = record?.song || record?.track || record;

      if (!song || typeof song !== "object") {
        return null;
      }

      const id = getSongId(song);

      if (id == null || seen.has(String(id))) {
        return null;
      }

      seen.add(String(id));

      return {
        ...record,
        ...song,
        id,
        artists:
          (Array.isArray(song?.artists) && song.artists.length
            ? song.artists
            : Array.isArray(record?.artists)
              ? record.artists
              : song?.artists),
        artist_ids:
          (Array.isArray(song?.artist_ids) && song.artist_ids.length
            ? song.artist_ids
            : Array.isArray(record?.artist_ids)
              ? record.artist_ids
              : song?.artist_ids),
        artist_id:
          song?.artist_id ??
          song?.artistId ??
          record?.artist_id ??
          record?.artistId ??
          song?.artist?.id ??
          song?.artist?.artist_id ??
          song?.artist_details?.id ??
          song?.artistDetails?.id ??
          record?.artist?.id ??
          null,
        played_at:
          record?.played_at ||
          record?.playedAt ||
          record?.last_played_at ||
          record?.created_at ||
          song?.played_at ||
          null,
      };
    })
    .filter(Boolean);
};

/* =========================================================
   HISTORY PAGE
========================================================= */

export default function History() {
  const {
    currentSong,
    isPlaying,
    playSong,
    togglePlay,
  } = usePlayer();

  const [history, setHistory] = useState([]);
  const [artistsById, setArtistsById] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [clearing, setClearing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  /* -------------------------------------------------------
     VOICE SEARCH
     Language selection is managed by VoiceSearch.jsx.
  ------------------------------------------------------- */

  const handleVoiceSearch = useCallback((recognizedText) => {
    setSearchQuery(recognizedText);
  }, []);

  /* -------------------------------------------------------
     CURRENT SONG HELPERS
  ------------------------------------------------------- */

  const isCurrentSong = useCallback(
    (song) => {
      const currentId = getSongId(currentSong);
      const songId = getSongId(song);

      return (
        currentId != null &&
        songId != null &&
        String(currentId) === String(songId)
      );
    },
    [currentSong]
  );

  const isSongPlaying = (song) =>
    isCurrentSong(song) && isPlaying;

  const isHistoryPlaying =
    history.some(isCurrentSong) && isPlaying;

  /* -------------------------------------------------------
     LOAD HISTORY
  ------------------------------------------------------- */

  const loadHistory = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      // Load history and the artist directory independently. Some history
      // responses contain only artist_id, so /artists supplies the English name.
      const [historyResult, artistsResult, songsResult] = await Promise.allSettled([
        API.get("/history"),
        API.get("/artists"),
        API.get("/songs"),
      ]);

      if (historyResult.status === "rejected") {
        throw historyResult.reason;
      }

      if (artistsResult.status === "fulfilled") {
        const artistsPayload = artistsResult.value?.data;
        const artistList = Array.isArray(artistsPayload)
          ? artistsPayload
          : Array.isArray(artistsPayload?.artists)
            ? artistsPayload.artists
            : Array.isArray(artistsPayload?.data)
              ? artistsPayload.data
              : Array.isArray(artistsPayload?.data?.artists)
                ? artistsPayload.data.artists
                : Array.isArray(artistsPayload?.results)
                  ? artistsPayload.results
                  : [];

        const artistLookup = {};

        artistList.forEach((artist) => {
          const artistId = artist?.id ?? artist?.artist_id ?? artist?.artistId;
          const englishName = firstEnglishName(
            artist?.name_english,
            artist?.english_name,
            artist?.nameEnglish,
            artist?.englishName,
            artist?.artist_name_english,
            artist?.artist_english,
            artist?.artist_name_en,
            artist?.name_en,
            artist?.name
          );

          if (artistId != null && englishName) {
            artistLookup[String(artistId)] = {
              ...artist,
              name_english: englishName,
            };
          }
        });

        setArtistsById(artistLookup);
      } else {
        console.warn(
          "Unable to load artist-name fallback list:",
          artistsResult.reason
        );
        setArtistsById({});
      }

      const historySongs = normalizeHistory(historyResult.value?.data);

      // History records can contain only the legacy primary artist. Merge the
      // complete song-level multi-artist relation from the main song catalogue.
      const songsPayload = songsResult.status === "fulfilled"
        ? songsResult.value?.data
        : [];
      const catalogueSongs = Array.isArray(songsPayload)
        ? songsPayload
        : songsPayload?.songs ||
          songsPayload?.data?.songs ||
          songsPayload?.data ||
          songsPayload?.items ||
          songsPayload?.results ||
          [];
      const catalogueById = new Map(
        (Array.isArray(catalogueSongs) ? catalogueSongs : [])
          .filter((song) => getSongId(song) != null)
          .map((song) => [String(getSongId(song)), song])
      );

      const enrichedHistory = historySongs.map((historySong) => {
        const catalogueSong = catalogueById.get(String(getSongId(historySong)));
        if (!catalogueSong) return historySong;

        const mergeArray = (key) => {
          const historyValue = Array.isArray(historySong?.[key]) ? historySong[key] : [];
          const catalogueValue = Array.isArray(catalogueSong?.[key]) ? catalogueSong[key] : [];
          return [...catalogueValue, ...historyValue];
        };

        return {
          ...catalogueSong,
          ...historySong,
          artists: mergeArray("artists"),
          song_artists: mergeArray("song_artists"),
          artist_ids: mergeArray("artist_ids"),
          artistIds: mergeArray("artistIds"),
        };
      });

      setHistory(enrichedHistory);
    } catch (err) {
      console.error(
        "Failed to load listening history:",
        err
      );

      setError(
        err?.response?.data?.message ||
          "Unable to load your listening history. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  /* -------------------------------------------------------
     FILTER HISTORY
  ------------------------------------------------------- */

  const query = searchQuery.trim().toLowerCase();

  const filteredHistory = history.filter((song) => {
    if (!query) return true;

    const title = getSongTitle(song).toLowerCase();
    const teluguTitle = getSongTeluguTitle(song).toLowerCase();
    const artist = getArtistNames(song, artistsById).toLowerCase();
    const album = getAlbumName(song).toLowerCase();

    const playedDate = formatPlayedDate(song.played_at)
      .toLowerCase();

    return (
      title.includes(query) ||
      teluguTitle.includes(query) ||
      artist.includes(query) ||
      album.includes(query) ||
      playedDate.includes(query)
    );
  });

  /* -------------------------------------------------------
     PLAY INDIVIDUAL SONG
  ------------------------------------------------------- */

  const handlePlaySong = async (song) => {
    if (!song) return;

    try {
      if (isCurrentSong(song)) {
        await togglePlay();
        return;
      }

      const index = filteredHistory.findIndex(
        (item) =>
          String(getSongId(item)) ===
          String(getSongId(song))
      );

      await playSong(
        song,
        filteredHistory,
        Math.max(index, 0)
      );
    } catch (err) {
      console.error("History playback failed:", err);
    }
  };

  /* -------------------------------------------------------
     PLAY ALL / PAUSE ALL
  ------------------------------------------------------- */

  const handlePlayAll = async () => {
    if (!filteredHistory.length) return;

    try {
      const containsCurrent = filteredHistory.some(
        isCurrentSong
      );

      if (containsCurrent) {
        await togglePlay();
        return;
      }

      await playSong(
        filteredHistory[0],
        filteredHistory,
        0
      );
    } catch (err) {
      console.error("Play All history failed:", err);
    }
  };

  /* -------------------------------------------------------
     CLEAR HISTORY
  ------------------------------------------------------- */

  const handleClearHistory = async () => {
    if (!history.length || clearing) return;

    const confirmed = window.confirm(
      "Are you sure you want to clear your listening history?"
    );

    if (!confirmed) return;

    setClearing(true);
    setError("");

    try {
      await API.delete("/history");

      setHistory([]);
      setSearchQuery("");
    } catch (err) {
      console.error(
        "Failed to clear listening history:",
        err
      );

      setError(
        err?.response?.data?.message ||
          "Unable to clear history. Please try again."
      );
    } finally {
      setClearing(false);
    }
  };

  /* -------------------------------------------------------
     COVER IMAGE
  ------------------------------------------------------- */

  const getCover = (song) => {
    const cover =
      song?.cover_url ||
      song?.coverUrl ||
      song?.album_cover ||
      song?.image_url;

    if (!cover) return "";

    try {
      return getMediaUrl(cover) || "";
    } catch {
      return "";
    }
  };

  /* -------------------------------------------------------
     RENDER
  ------------------------------------------------------- */

  return (
    <main className="history-page">
      <section className="history-container">

        {/* PAGE HEADER */}

        <header className="history-header">
          <div className="history-heading">
            <span className="history-heading-icon">
              <FaHistory />
            </span>

            <div>
              <p className="history-eyebrow">
                YOUR MUSIC JOURNEY
              </p>

              <h1>Listening History</h1>

              <p className="history-subtitle">
                Return to the songs that have been part of
                your worship.
              </p>
            </div>
          </div>

          <div className="history-count">
            <FaClock />

            <span>
              {history.length}{" "}
              {history.length === 1 ? "song" : "songs"}
            </span>
          </div>
        </header>

        {/* TOOLBAR */}

        <div className="history-toolbar">
          <div className="history-toolbar-left">
            <button
              type="button"
              className={`history-play-all ${
                isHistoryPlaying ? "is-playing" : ""
              }`}
              onClick={handlePlayAll}
              disabled={
                loading || filteredHistory.length === 0
              }
              aria-label={
                isHistoryPlaying
                  ? "Pause listening history"
                  : "Play songs in listening history"
              }
            >
              {isHistoryPlaying ? <FaPause /> : <FaPlay />}

              <span>
                {isHistoryPlaying ? "Pause All" : "Play All"}
              </span>
            </button>

            <span className="history-toolbar-caption">
              {filteredHistory.length > 0
                ? query
                  ? `Play ${filteredHistory.length} matching ${
                      filteredHistory.length === 1
                        ? "song"
                        : "songs"
                    }`
                  : "Play your recently listened songs"
                : history.length > 0
                  ? "No songs match your search"
                  : "Your recently played songs will appear here"}
            </span>
          </div>

          <button
            type="button"
            className="history-clear-button"
            onClick={handleClearHistory}
            disabled={
              loading || clearing || history.length === 0
            }
          >
            <FaTrash />

            <span>
              {clearing ? "Clearing..." : "Clear History"}
            </span>
          </button>
        </div>

        {/* SINGLE SEARCH BAR + LANGUAGE SELECTOR */}

        <section
          className="history-search-controls"
          aria-label="Search listening history"
         >
          <div className="history-search">
            <VoiceSearch
              value={searchQuery}
              onChange={setSearchQuery}
              onSearch={handleVoiceSearch}
              placeholder="Search songs, artists, or albums..."
              ariaLabel="Search listening history by voice or text"
            />
          </div>

          
        </section>

        {/* SEARCH RESULTS SUMMARY */}

        {!loading && history.length > 0 && query && (
          <p
            className="history-search-summary"
            aria-live="polite"
          >
            {filteredHistory.length}{" "}
            {filteredHistory.length === 1 ? "song" : "songs"}{" "}
            found
          </p>
        )}

        {/* ERROR */}

        {error && (
          <div className="history-error" role="alert">
            <span>{error}</span>

            <button
              type="button"
              onClick={loadHistory}
              disabled={loading}
            >
              Try again
            </button>
          </div>
        )}

        {/* LOADING / EMPTY / RESULTS */}

        {loading ? (
          <div className="history-status">
            <span className="history-spinner" />
            <p>Loading your listening history...</p>
          </div>
        ) : history.length === 0 ? (
          <div className="history-empty">
            <div className="history-empty-icon">
              <FaMusic />
            </div>

            <h2>Your history is waiting</h2>

            <p>
              Songs you listen to will appear here, making it
              easy to find your favourite worship music again.
            </p>
          </div>
        ) : filteredHistory.length === 0 ? (
          <div className="history-empty history-no-results">
            <div className="history-empty-icon">
              <FaSearch />
            </div>

            <h2>No matching songs</h2>

            <p>
              No songs match "{searchQuery.trim()}". Try
              searching for another title, artist, or album.
            </p>

            <button
              type="button"
              className="history-reset-search"
              onClick={() => setSearchQuery("")}
            >
              <FaTimes />
              Clear search
            </button>
          </div>
        ) : (
          <section className="history-list-section">
            <div className="history-list-heading">
              <h2>
                {query ? "Search Results" : "Recently Played"}
              </h2>

              <span>
                {filteredHistory.length}{" "}
                {filteredHistory.length === 1
                  ? "track"
                  : "tracks"}
              </span>
            </div>

            {/* TABLE HEADER */}

            <div className="history-table-header">
              <span className="history-number-heading">#</span>
              <span className="history-song-heading">Song</span>
              <span className="history-date-heading">
                Last Played
              </span>
            </div>

            {/* SONG ROWS */}

            <div
              className="history-song-list"
              id="history-song-list"
            >
              {filteredHistory.map((song, index) => {
                const songId = getSongId(song);
                const playing = isSongPlaying(song);
                const selected = isCurrentSong(song);

                return (
                  <article
                    className={`history-row ${
                      selected ? "is-current-song" : ""
                    }`}
                    key={songId ?? index}
                  >
                    {/* PLAY / PAUSE */}

                    <div className="history-row-number">
                    

                      <button
                        type="button"
                        className="history-row-play"
                        onClick={() => handlePlaySong(song)}
                        aria-label={`${
                          playing ? "Pause" : "Play"
                        } ${getSongTitle(song)}`}
                        title={playing ? "Pause song" : "Play song"}
                      >
                        {playing ? <FaPause /> : <FaPlay />}
                      </button>
                    </div>

                    {/* SONG DETAILS */}

                    <button
                      type="button"
                      className="history-song-info history-song-open"
                      onClick={() => handlePlaySong(song)}
                      aria-label={`${
                        playing ? "Pause" : "Play"
                      } ${getSongTitle(song)}`}
                    >
                      {getCover(song) && (
                        <img
                          className="history-cover"
                          src={getCover(song)}
                          alt=""
                          loading="lazy"
                          onError={(event) => {
                            event.currentTarget.onerror = null;
                            event.currentTarget.style.display = "none";
                          }}
                        />
                      )}

                      <div className="history-song-text">
                        <h3 title={getSongTitle(song)}>
                          {getSongTitle(song)}
                        </h3>

                        {getSongTeluguTitle(song) && (
                          <span
                            className="history-song-telugu-title"
                            style={{
                              display: "block",
                              fontSize: "0.86em",
                              fontWeight: 400,
                              opacity: 0.78,
                              marginTop: "2px",
                            }}
                            title={getSongTeluguTitle(song)}
                          >
                            {getSongTeluguTitle(song)}
                          </span>
                        )}

                        <p title={getArtistNames(song, artistsById)}>
                          {getArtistNames(song, artistsById)}
                        </p>
                      </div>
                    </button>


                    {/* LAST PLAYED */}

                    <div className="history-date">
                      <FaClock className="history-date-icon" />

                      <span>
                        {formatPlayedDate(song.played_at)}
                      </span>
                    </div>
                  </article>
                );
              })}
            </div>
          </section>
        )}
      </section>
    </main>
  );
}
