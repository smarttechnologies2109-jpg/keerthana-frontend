
import {
  Fragment,
  createElement,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import { Capacitor } from "@capacitor/core";

import {
  AdMob,
  AdmobConsentStatus,
  NativeAdFeed,
  NativeAdTemplate,
} from "@capacitor-community/admob";

import {
  FaCompactDisc,
  FaEllipsisV,
  FaHeart,
  FaListUl,
  FaMusic,
  FaPause,
  FaPlay,
  FaPlus,
  FaRegHeart,
  FaStepForward,
} from "react-icons/fa";

import API from "../services/api";
import { usePlayer } from "../context/usePlayer";
import { useLikedSongs } from "../context/LikedSongsContext";

import {
  getSongCover,
 
} from "../utils/media";

import VoiceSearch from "../components/VoiceSearch";

import "../assets/css/allSongs.css";

import { useNavigate } from "react-router-dom";

/* =====================================================
   LANGUAGE FILTERS
   Native-script labels with API-compatible values
===================================================== */

const LANGUAGES = [
  { value: "All", label: "All Languages" },
  { value: "Telugu", label: "తెలుగు" },
  { value: "English", label: "English" },
  { value: "Hindi", label: "हिन्दी" },
  { value: "Malayalam", label: "മലയാളം" },
  { value: "Kannada", label: "ಕನ್ನಡ" },
  { value: "Tamil", label: "தமிழ்" },
];

const normalizeLanguage = (value) => {
  const raw = String(value || "").trim().toLowerCase();

  const aliases = {
    te: "Telugu",
    "te-in": "Telugu",
    telugu: "Telugu",
    "తెలుగు": "Telugu",
    en: "English",
    "en-in": "English",
    english: "English",
    hi: "Hindi",
    "hi-in": "Hindi",
    hindi: "Hindi",
    "हिन्दी": "Hindi",
    "हिंदी": "Hindi",
    ml: "Malayalam",
    "ml-in": "Malayalam",
    malayalam: "Malayalam",
    "മലയാളം": "Malayalam",
    kn: "Kannada",
    "kn-in": "Kannada",
    kannada: "Kannada",
    "ಕನ್ನಡ": "Kannada",
    ta: "Tamil",
    "ta-in": "Tamil",
    tamil: "Tamil",
    "தமிழ்": "Tamil",
  };

  return aliases[raw] || String(value || "").trim();
};

/* =====================================================
   LANGUAGE-SPECIFIC UI TEXT
===================================================== */

const LANGUAGE_TEXT = {
  All: {
    allSongs: "All Songs",
    search: "Search songs, artists, and albums...",
    songs: "songs",
    playAll: "Play All",
    clearFilters: "Clear Filters",
    emptyTitle: "No songs found",
    emptyMessage:
      "Try another search or choose a different language.",
    loadingTitle: "Loading songs...",
  },

  Telugu: {
    allSongs: "అన్ని పాటలు",
    search: "పాటలు, గాయకులు, ఆల్బమ్‌లను వెతకండి...",
    searchHint: "పాట, గాయకుడు, ఆల్బమ్ లేదా మూడ్ ద్వారా వెతకండి",
    songs: "పాటలు",
    playAll: "అన్నీ ప్లే చేయండి",
    clearFilters: "ఫిల్టర్లను తొలగించండి",
    emptyTitle: "పాటలు కనబడలేదు",
    emptyMessage:
      "మరో పదంతో వెతకండి లేదా వేరే భాషను ఎంచుకోండి.",
    loadingTitle: "పాటలు లోడ్ అవుతున్నాయి...",
  },

  English: {
    allSongs: "All Songs",
    search: "Search songs, artists, and albums...",
    songs: "songs",
    playAll: "Play All",
    clearFilters: "Clear Filters",
    emptyTitle: "No songs found",
    emptyMessage:
      "Try another search or choose a different language.",
    loadingTitle: "Loading songs...",
  },

  Hindi: {
    allSongs: "सभी गाने",
    search: "गाने, गायक और एल्बम खोजें...",
    searchHint: "गाने, गायक, एल्बम या मूड से खोजें",
    songs: "गाने",
    playAll: "सभी चलाएँ",
    clearFilters: "फ़िल्टर हटाएँ",
    emptyTitle: "कोई गाना नहीं मिला",
    emptyMessage:
      "दूसरे शब्द से खोजें या कोई दूसरी भाषा चुनें।",
    loadingTitle: "गाने लोड हो रहे हैं...",
  },

  Malayalam: {
    allSongs: "എല്ലാ പാട്ടുകളും",
    search: "പാട്ടുകൾ, ഗായകർ, ആൽബങ്ങൾ തിരയുക...",
    searchHint: "പാട്ട്, ഗായകൻ, ആൽബം അല്ലെങ്കിൽ മൂഡ് തിരയുക",
    songs: "പാട്ടുകൾ",
    playAll: "എല്ലാം പ്ലേ ചെയ്യുക",
    clearFilters: "ഫിൽട്ടറുകൾ നീക്കുക",
    emptyTitle: "പാട്ടുകളൊന്നും കണ്ടെത്തിയില്ല",
    emptyMessage:
      "മറ്റൊരു വാക്ക് തിരയുക അല്ലെങ്കിൽ മറ്റൊരു ഭാഷ തിരഞ്ഞെടുക്കുക.",
    loadingTitle: "പാട്ടുകൾ ലോഡ് ചെയ്യുന്നു...",
  },

  Kannada: {
    allSongs: "ಎಲ್ಲಾ ಹಾಡುಗಳು",
    search: "ಹಾಡುಗಳು, ಗಾಯಕರು ಮತ್ತು ಆಲ್ಬಮ್‌ಗಳನ್ನು ಹುಡುಕಿ...",
    searchHint: "ಹಾಡು, ಗಾಯಕ, ಆಲ್ಬಮ್ ಅಥವಾ ಮೂಡ್ ಹುಡುಕಿ",
    songs: "ಹಾಡುಗಳು",
    playAll: "ಎಲ್ಲವನ್ನೂ ಪ್ಲೇ ಮಾಡಿ",
    clearFilters: "ಫಿಲ್ಟರ್‌ಗಳನ್ನು ತೆರವುಗೊಳಿಸಿ",
    emptyTitle: "ಯಾವುದೇ ಹಾಡುಗಳು ಕಂಡುಬಂದಿಲ್ಲ",
    emptyMessage:
      "ಬೇರೆ ಪದದಿಂದ ಹುಡುಕಿ ಅಥವಾ ಬೇರೆ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ.",
    loadingTitle: "ಹಾಡುಗಳನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುತ್ತಿದೆ...",
  },

  Tamil: {
    allSongs: "அனைத்து பாடல்கள்",
    search: "பாடல்கள், பாடகர்கள் மற்றும் ஆல்பங்களைத் தேடுங்கள்...",
    searchHint: "பாடல், பாடகர், ஆல்பம் அல்லது மனநிலை மூலம் தேடுங்கள்",
    songs: "பாடல்கள்",
    playAll: "அனைத்தையும் இயக்கு",
    clearFilters: "வடிகட்டிகளை நீக்கு",
    emptyTitle: "பாடல்கள் எதுவும் கிடைக்கவில்லை",
    emptyMessage:
      "வேறு சொல்லைத் தேடுங்கள் அல்லது வேறு மொழியைத் தேர்ந்தெடுக்கவும்.",
    loadingTitle: "பாடல்கள் ஏற்றப்படுகின்றன...",
  },
};

/* =====================================================
   HELPERS
===================================================== */

const getSongId = (song) =>
  song?.id ?? song?.song_id;

const getSongTitle = (song) =>
  song?.title_english ||
  song?.english_title ||
  song?.title_telugu ||
  song?.title ||
  "Untitled Song";

/*
 * All Songs title order:
 * 1. English title first.
 * 2. Telugu/native-script title underneath.
 * The selected language filter does not change this display order.
 */
const getSongDisplayTitles = (song) => {
  const englishTitle =
    song?.title_english ||
    song?.english_title ||
    "";

  const nativeTitle =
    song?.title_telugu ||
    song?.title ||
    "";

  const primary = englishTitle || nativeTitle || "Untitled Song";
  const secondary = nativeTitle;

  return {
    primary,
    secondary:
      secondary && secondary.trim() !== primary.trim()
        ? secondary
        : "",
  };
};

/*
 * Artist names must always be English, regardless of the selected
 * language. Telugu-script values are deliberately rejected.
 */
const containsTelugu = (value) =>
  /[\u0C00-\u0C7F]/.test(String(value || ""));

const getArtistName = (song, artistsById = {}) => {
  const candidates = [];

  // Preferred API response: [{ id, name_english, ... }, ...]
  if (Array.isArray(song?.artists)) {
    candidates.push(...song.artists);
  }

  // Support the join-table response shape: song_artists.
  if (Array.isArray(song?.song_artists)) {
    candidates.push(...song.song_artists);
  }

  // Some APIs return artist IDs separately.
  if (Array.isArray(song?.artist_ids)) {
    candidates.push(...song.artist_ids);
  }

  // Legacy single artist fields.
  if (!candidates.length) {
    if (Array.isArray(song?.artist)) {
      candidates.push(...song.artist);
    } else if (song?.artist && typeof song.artist === "object") {
      candidates.push(song.artist);
    } else if (song?.artist_id != null || song?.artistId != null) {
      candidates.push(song.artist_id ?? song.artistId);
    } else if (typeof song?.artist === "string" && song.artist.trim()) {
      candidates.push(song.artist);
    }
  }

  const names = [];
  const addName = (value) => {
    if (
      typeof value === "string" &&
      value.trim() &&
      !containsTelugu(value)
    ) {
      const cleanName = value.trim();
      if (!names.some((name) => name.toLowerCase() === cleanName.toLowerCase())) {
        names.push(cleanName);
      }
    }
  };

  const getEnglishName = (artist) => {
    if (!artist || typeof artist !== "object") return "";

    return (
      artist.name_english ||
      artist.english_name ||
      artist.nameEnglish ||
      artist.englishName ||
      artist.artist_name_english ||
      artist.artist_english_name ||
      // Some artist records store their English display name in `name`.
      (!containsTelugu(artist.name) ? artist.name : "")
    );
  };

  candidates.forEach((candidate) => {
    if (candidate == null) return;

    const candidateId =
      typeof candidate === "object"
        ? candidate.id ?? candidate.artist_id
        : typeof candidate === "number" ||
            /^\d+$/.test(String(candidate).trim())
          ? candidate
          : null;

    const linkedArtist =
      candidateId != null
        ? artistsById[String(candidateId)] || {}
        : {};

    if (typeof candidate === "object") {
      addName(getEnglishName(candidate));
      addName(getEnglishName(linkedArtist));
    } else if (candidateId != null) {
      addName(getEnglishName(linkedArtist));
    } else {
      addName(candidate);
    }
  });

  // Direct English fields from older /songs API responses.
  [
    song?.artist_name_english,
    song?.artist_english,
    song?.artist_english_name,
    song?.artist_name_en,
    song?.artistEnglishName,
    song?.artistNameEnglish,
    song?.artistEnglish,
    song?.artist_name,
    song?.artistName,
  ].forEach(addName);

  // Keep a clear fallback if the API does not provide linked artist data.
  return names.length ? names.join(", ") : "Unknown Artist";
};
const getAlbumName = (song) =>
  song?.album_name ||
  song?.album?.title ||
  (typeof song?.album === "string"
    ? song.album
    : "");

const getLanguage = (song) =>
  normalizeLanguage(song?.language || "Telugu");

const normalizeSong = (song) => ({
  ...song,
  id: getSongId(song),
});

/* =====================================================
   ADMOB NATIVE FEED CONFIGURATION
   Test ads are used during development.
===================================================== */

const NATIVE_AD_FEED_ID = "keerthana-all-songs";
const NATIVE_AD_INTERVAL = 4;
const MAX_NATIVE_AD_SLOTS = 3;


/* =====================================================
   ALL SONGS PAGE
===================================================== */

export default function AllSongs() {
  const navigate = useNavigate();

  const player = usePlayer();
  const likedContext = useLikedSongs();

  const {
    currentSong,
    isPlaying,
    playSong,
    togglePlay,
    addToQueue,
  } = player;

  const { isLiked, toggleLike } = likedContext;

  /* ---------------------------------------------------
     STATE
  --------------------------------------------------- */

  const [songs, setSongs] = useState([]);
  const [artistsById, setArtistsById] = useState({});
  const [nativeAdsReady, setNativeAdsReady] = useState(false);
  const nativeAdFeedRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [error, setError] = useState("");

  const isFetchingRef = useRef(false);
  const pendingRefreshRef = useRef(false);
  const hasSongsRef = useRef(false);
  const touchStartYRef = useRef(null);
  const shouldRefreshOnTouchEndRef = useRef(false);

  const [search, setSearch] = useState("");
  const [language, setLanguage] = useState("All");

  const [menuSongId, setMenuSongId] = useState(null);
  const [notice, setNotice] = useState("");

  const menuRef = useRef(null);

  const currentSongId = getSongId(currentSong);

  /* ---------------------------------------------------
     CURRENT LANGUAGE TEXT
  --------------------------------------------------- */

  const languageText =
    LANGUAGE_TEXT[language] || LANGUAGE_TEXT.All;

  /* ===================================================
     LOAD SONGS
  =================================================== */

  const loadSongs = useCallback(async ({ silent = false } = {}) => {
    // Avoid overlapping requests from pull-to-refresh and app-resume events.
    if (isFetchingRef.current) {
      return false;
    }

    isFetchingRef.current = true;

    if (!silent) {
      setLoading(true);
      setError("");
    }

    try {
      const response = await API.get("/songs");

      // Some API responses include artist_name_english directly, while
      // others only include artist_id. Load the artists list as a reliable
      // fallback so All Songs can display the same English artist name
      // already shown on Album Details and Artist Details.
      try {
        const artistsResponse = await API.get("/artists");
        const artistsPayload = artistsResponse?.data;
        const artistList = Array.isArray(artistsPayload)
          ? artistsPayload
          : Array.isArray(artistsPayload?.artists)
            ? artistsPayload.artists
            : Array.isArray(artistsPayload?.data)
              ? artistsPayload.data
              : [];

        const artistLookup = {};
        artistList.forEach((artist) => {
          const artistId = artist?.id ?? artist?.artist_id;
          const englishName =
            artist?.name_english ||
            artist?.english_name ||
            artist?.nameEnglish ||
            (!containsTelugu(artist?.name) ? artist?.name : "") ||
            "";

          if (artistId != null && englishName && !containsTelugu(englishName)) {
            artistLookup[String(artistId)] = {
              ...artist,
              name_english: String(englishName).trim(),
            };
          }
        });

        setArtistsById(artistLookup);
      } catch (artistError) {
        // Keep the songs page usable even if the artists endpoint fails.
        console.warn(
          "Unable to load artist-name fallback list:",
          artistError
        );
      }

      const payload = response?.data;

      const list = Array.isArray(payload)
        ? payload
        : Array.isArray(payload?.songs)
          ? payload.songs
          : Array.isArray(payload?.data)
            ? payload.data
            : [];

      const validSongs = list
        .map(normalizeSong)
        .filter((song) => song.id != null);

      validSongs.sort((a, b) =>
        getSongTitle(a).localeCompare(getSongTitle(b))
      );

      setSongs(validSongs);
      hasSongsRef.current = validSongs.length > 0;

      if (silent) {
        setError("");
      }

      return true;
    } catch (err) {
      console.error("Failed to load songs:", err);

      // During a silent refresh, keep the already displayed songs.
      // Show an error only if there is no existing data to display.
      if (!silent || !hasSongsRef.current) {
        setError(
          err?.response?.data?.message ||
            "Unable to load songs. Please try again."
        );
      }

      return false;
    } finally {
      // Always release the request lock, including failed requests.
      isFetchingRef.current = false;

      if (!silent) {
        setLoading(false);
      }

      // If a refresh was requested while the initial/API request was
      // still running, perform one fresh request after the lock is released.
      if (pendingRefreshRef.current) {
        pendingRefreshRef.current = false;

        window.setTimeout(async () => {
          setRefreshing(true);
          try {
            await loadSongs({ silent: true });
          } finally {
            setRefreshing(false);
            setPullDistance(0);
          }
        }, 0);
      }
    }
  }, []);

  const refreshSongs = useCallback(async () => {
    // Do not lose a user refresh just because another request is finishing.
    // Queue exactly one follow-up request instead.
    if (isFetchingRef.current) {
      pendingRefreshRef.current = true;
      setRefreshing(true);
      return;
    }

    setRefreshing(true);

    try {
      await loadSongs({ silent: true });
    } finally {
      setRefreshing(false);
      setPullDistance(0);
    }
  }, [loadSongs]);

  useEffect(() => {
    loadSongs();
  }, [loadSongs]);

  /* ===================================================
     ADMOB NATIVE ADS
     - Android only
     - Reuses the app's published consent configuration
     - Google test ads during development
     - Feed is destroyed when leaving All Songs
  =================================================== */

  useEffect(() => {
    if (
      !Capacitor.isNativePlatform() ||
      Capacitor.getPlatform() !== "android"
    ) {
      return undefined;
    }

    let active = true;
    let createdFeed = null;

    const initializeNativeFeed = async () => {
      try {
        console.info(
          "[KEERTHANA Native Ads] Checking consent..."
        );

        let consentInfo = await AdMob.requestConsentInfo();

        if (
          consentInfo?.isConsentFormAvailable &&
          consentInfo?.status === AdmobConsentStatus.REQUIRED
        ) {
          consentInfo = await AdMob.showConsentForm();
        }

        if (!active) return;

        if (!consentInfo?.canRequestAds) {
          console.warn(
            "[KEERTHANA Native Ads] Ads cannot be requested until consent is ready."
          );
          return;
        }

        // AdMob.initialize() is safe to call here even if the
        // banner component has already initialized the SDK.
        await AdMob.initialize();

        if (!active) return;

        createdFeed = await NativeAdFeed.create({
          feedId: NATIVE_AD_FEED_ID,
          adId: "ca-app-pub-4269202427991524/7049379561",
          template: NativeAdTemplate.Medium,
          isTesting: false,
          androidScrollSnapshot: true,
          style: {
            backgroundColor: "#101d35",
            cornerRadius: 14,
            headlineColor: "#f5f7fb",
            callToActionBackgroundColor: "#d4af65",
          },
        });

        if (!active) {
          await createdFeed.destroy();
          createdFeed = null;
          return;
        }

        nativeAdFeedRef.current = createdFeed;
        setNativeAdsReady(true);

        console.info(
          "[KEERTHANA Native Ads] Google test native feed is ready."
        );
      } catch (error) {
        console.error(
          "[KEERTHANA Native Ads] Feed initialization failed:",
          error
        );
      }
    };

    initializeNativeFeed();

    return () => {
      active = false;
      setNativeAdsReady(false);

      const feedToDestroy =
        nativeAdFeedRef.current || createdFeed;

      nativeAdFeedRef.current = null;
      createdFeed = null;

      if (feedToDestroy) {
        feedToDestroy.destroy().catch((error) => {
          console.warn(
            "[KEERTHANA Native Ads] Feed cleanup warning:",
            error
          );
        });
      }
    };
  }, []);

  /* ===================================================
     REFRESH WHEN APP RETURNS TO FOREGROUND
     App.jsx dispatches "keerthana:app-resume".
  =================================================== */

  useEffect(() => {
    const handleAppResume = () => {
      refreshSongs();
    };

    window.addEventListener(
      "keerthana:app-resume",
      handleAppResume
    );

    return () => {
      window.removeEventListener(
        "keerthana:app-resume",
        handleAppResume
      );
    };
  }, [refreshSongs]);

  /* ===================================================
     PULL DOWN TO REFRESH
     Only activates when the page is already at the top.
  =================================================== */

  const handleTouchStart = useCallback((event) => {
    if (window.scrollY > 1 || event.touches.length !== 1) {
      touchStartYRef.current = null;
      shouldRefreshOnTouchEndRef.current = false;
      return;
    }

    touchStartYRef.current = event.touches[0].clientY;
    shouldRefreshOnTouchEndRef.current = false;
  }, []);

  const handleTouchMove = useCallback((event) => {
    if (touchStartYRef.current === null || refreshing) {
      return;
    }

    if (window.scrollY > 1 || event.touches.length !== 1) {
      touchStartYRef.current = null;
      shouldRefreshOnTouchEndRef.current = false;
      setPullDistance(0);
      return;
    }

    const currentY = event.touches[0].clientY;
    const distance = Math.max(0, currentY - touchStartYRef.current);
    const limitedDistance = Math.min(distance * 0.5, 90);

    setPullDistance(limitedDistance);
    shouldRefreshOnTouchEndRef.current = limitedDistance >= 65;
  }, [refreshing]);

  const handleTouchEnd = useCallback(() => {
    const shouldRefresh = shouldRefreshOnTouchEndRef.current;

    touchStartYRef.current = null;
    shouldRefreshOnTouchEndRef.current = false;
    setPullDistance(0);

    if (shouldRefresh) {
      refreshSongs();
    }
  }, [refreshSongs]);

  const handleTouchCancel = useCallback(() => {
    touchStartYRef.current = null;
    shouldRefreshOnTouchEndRef.current = false;
    setPullDistance(0);
  }, []);

  /* ===================================================
     CLOSE MENU ON OUTSIDE CLICK OR ESCAPE
  =================================================== */

  useEffect(() => {
    const handlePointerDown = (event) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target)
      ) {
        setMenuSongId(null);
      }
    };

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setMenuSongId(null);
      }
    };

    document.addEventListener(
      "pointerdown",
      handlePointerDown
    );

    document.addEventListener(
      "keydown",
      handleKeyDown
    );

    return () => {
      document.removeEventListener(
        "pointerdown",
        handlePointerDown
      );

      document.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, []);

  /* ===================================================
     TEMPORARY FEEDBACK
  =================================================== */

  useEffect(() => {
    if (!notice) return undefined;

    const timeout = window.setTimeout(
      () => setNotice(""),
      2600
    );

    return () => window.clearTimeout(timeout);
  }, [notice]);

  const showNotice = useCallback((message) => {
    setNotice(message);
  }, []);

  /* ===================================================
     SEARCH AND LANGUAGE FILTER
  =================================================== */

  const filteredSongs = useMemo(() => {
    const query = search
      .trim()
      .toLocaleLowerCase();

    return songs.filter((song) => {
      const matchesLanguage =
        language === "All" ||
        getLanguage(song).toLowerCase() ===
          language.toLowerCase();

      const moods = Array.isArray(song.moods)
        ? song.moods
        : [];

      const searchableText = [
        song.title,
        song.title_telugu,
        song.title_english,
        song.english_title,
        getArtistName(song, artistsById),
        getAlbumName(song),
        song.category_name,
        song.category?.name,
        getLanguage(song),
        ...moods,
      ]
        .filter(Boolean)
        .join(" ")
        .toLocaleLowerCase();

      return (
        matchesLanguage &&
        searchableText.includes(query)
      );
    });
  }, [songs, search, language, artistsById]);

  /* ===================================================
     PLAY SONG
  =================================================== */

  const handlePlay = useCallback(
    (song, list = filteredSongs) => {
      const normalizedSong = normalizeSong(song);

      if (
        currentSongId === normalizedSong.id &&
        typeof togglePlay === "function"
      ) {
        togglePlay();
        return;
      }

      if (typeof playSong !== "function") {
        showNotice("Player is unavailable right now.");
        return;
      }

      const playlist = list.map(normalizeSong);

      const index = playlist.findIndex(
        (item) => item.id === normalizedSong.id
      );

      playSong(
        normalizedSong,
        playlist,
        index >= 0 ? index : 0
      );
    },
    [
      currentSongId,
      filteredSongs,
      playSong,
      togglePlay,
      showNotice,
    ]
  );

  /* ===================================================
     PLAY ALL
  =================================================== */

  const isFilteredPlaylistActive = filteredSongs.some(
    (song) => getSongId(song) === currentSongId
  );

  const isPlayAllPlaying = isFilteredPlaylistActive && isPlaying;

  const handlePlayAll = () => {
    if (!filteredSongs.length) return;

    // If this filtered playlist is already active, toggle play/pause.
    if (isFilteredPlaylistActive && typeof togglePlay === "function") {
      togglePlay();
      return;
    }

    // Otherwise start the filtered playlist from its first song.
    handlePlay(filteredSongs[0], filteredSongs);
  };

  /* ===================================================
     ADD TO QUEUE
  =================================================== */

  const handleAddToQueue = (song) => {
    if (typeof addToQueue !== "function") {
      showNotice("Queue is unavailable right now.");
      return;
    }

    addToQueue(normalizeSong(song));

    setMenuSongId(null);

    showNotice("Added to your queue");
  };

  /* ===================================================
     PLAY NEXT
  =================================================== */

  const handlePlayNext = (song) => {
    const normalizedSong = normalizeSong(song);

    if (typeof player.playNext === "function") {
      player.playNext(normalizedSong);

      setMenuSongId(null);

      showNotice("Added to play next");
      return;
    }

    if (
      Array.isArray(player.queue) &&
      typeof player.setQueue === "function"
    ) {
      const queue = player.queue.map(normalizeSong);

      const duplicateIndex = queue.findIndex(
        (item) => item.id === normalizedSong.id
      );

      if (duplicateIndex >= 0) {
        queue.splice(duplicateIndex, 1);
      }

      const currentIndex = Number.isInteger(
        player.currentIndex
      )
        ? player.currentIndex
        : -1;

      queue.splice(
        Math.max(0, currentIndex + 1),
        0,
        normalizedSong
      );

      player.setQueue(queue);

      setMenuSongId(null);

      showNotice("Added to play next");
      return;
    }

    handleAddToQueue(normalizedSong);
  };

  /* ===================================================
     LIKE / UNLIKE
  =================================================== */

  const handleToggleLike = async (song) => {
    if (typeof toggleLike !== "function") {
      showNotice("Liked Songs is unavailable right now.");
      return;
    }

    const wasLiked = Boolean(
      isLiked?.(getSongId(song))
    );

    try {
      await toggleLike(normalizeSong(song));

      setMenuSongId(null);

      showNotice(
        wasLiked
          ? "Removed from Liked Songs"
          : "Added to Liked Songs"
      );
    } catch (err) {
      console.error(
        "Unable to update liked song:",
        err
      );

      showNotice("Couldn't update Liked Songs");
    }
  };

  /* ===================================================
     PLAYLIST INTEGRATION
  =================================================== */

  const handleAddToPlaylist = (song) => {
    setMenuSongId(null);

    navigate("/playlists", {
      state: {
        selectedSong: normalizeSong(song),
        action: "add-song",
      },
    });
  };

  /* ===================================================
     ALBUM NAVIGATION
     Existing event integration preserved.
  =================================================== */

  const handleViewAlbum = (song) => {
    const albumId =
      song?.album_id ??
      song?.album?.id ??
      song?.album?.album_id;

    setMenuSongId(null);

    if (!albumId) {
      showNotice("This song has no linked album.");
      return;
    }

    window.dispatchEvent(
      new CustomEvent("keerthana:view-album", {
        detail: {
          albumId,
          song: normalizeSong(song),
        },
      })
    );

    showNotice(
      "Connect this action to your album details route."
    );
  };

  /* ===================================================
     VOICE SEARCH
     AWS automatically identifies the spoken language.
     Transcript updates the existing search state.
  =================================================== */

  const handleVoiceSearchChange = useCallback(
    (nextValue) => {
      setSearch(nextValue);
    },
    []
  );

  const handleVoiceSearchSubmit = useCallback(
    (spokenText) => {
      const searchText = String(
        spokenText || ""
      ).trim();

      if (searchText) {
        setSearch(searchText);
      }
    },
    []
  );

  /* ===================================================
     RENDER
  =================================================== */

  return (
    <main
      className="all-songs-page"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchCancel}
    >

      {/* PULL-TO-REFRESH INDICATOR */}

      {(refreshing || pullDistance > 0) && (
        <div
          className="all-songs-refresh-indicator"
          role="status"
          aria-live="polite"
          style={{
            minHeight: "42px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "10px",
            color: "#d4af65",
            fontSize: "13px",
            fontWeight: 600,
            opacity: refreshing ? 1 : Math.min(pullDistance / 65, 1),
            transform: `translateY(${refreshing ? 0 : Math.min(pullDistance * 0.25, 22)}px)`,
            transition: refreshing ? "opacity 180ms ease" : "none",
          }}
        >
          <span
            aria-hidden="true"
            style={{
              width: "16px",
              height: "16px",
              border: "2px solid rgba(212, 175, 101, 0.3)",
              borderTopColor: "#d4af65",
              borderRadius: "50%",
              display: "inline-block",
              animation: refreshing ? "allSongsRefreshSpin 0.8s linear infinite" : "none",
              transform: refreshing ? "none" : `rotate(${pullDistance * 4}deg)`,
            }}
          />
          {refreshing
            ? "Refreshing songs..."
            : pullDistance >= 65
              ? "Release to refresh"
              : "Pull down to refresh"}
          <style>{`
            @keyframes allSongsRefreshSpin {
              to { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      )}

      {/* PAGE HEADER */}

      <header className="all-songs-header">
        <div className="all-songs-title-area">

          <div
            className="all-songs-icon"
            aria-hidden="true"
          >
            <FaMusic />
          </div>

          <div className="all-songs-heading">

            <span className="all-songs-overline">
              YOUR WORSHIP LIBRARY
            </span>

            <h1>{languageText.allSongs}</h1>

            <p>{languageText.searchHint}</p>

          </div>
        </div>
      </header>

      {/* SEARCH */}

      <section
        className="all-songs-search-section"
        aria-label="Search songs"
      >

        <VoiceSearch
          value={search}
          onChange={handleVoiceSearchChange}
          onSearch={handleVoiceSearchSubmit}
          placeholder={languageText.search}
          ariaLabel="Search songs, artists, albums and lyrics"
        />

      </section>

      {/* RESULTS */}

      <section className="all-songs-results">

        <div className="all-songs-results-heading">

          {/* ALL SONGS TITLE */}

          <div className="all-songs-results-title">
            <h2>{languageText.allSongs}</h2>
          </div>

          {/* PLAY ALL LEFT / LANGUAGE FILTER RIGHT */}

          <div
            className="all-songs-play-all-row"
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: "14px",
            }}
          >
            <button
              type="button"
              className="all-songs-play-all"
              onClick={handlePlayAll}
              disabled={!filteredSongs.length || loading}
              style={{ flexShrink: 0, order: 1 }}
            >
              {isPlayAllPlaying ? <FaPause /> : <FaPlay />}
              {languageText.playAll}
            </button>

            <label
              className="all-songs-language-dropdown"
              aria-label="Select song language"
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "flex-end",
                gap: "8px",
                margin: 0,
                marginLeft: "auto",
                order: 2,
              }}
            >
              <span
                style={{
                  color: "var(--text-secondary, #aebbd0)",
                  fontSize: "13px",
                  fontWeight: 600,
                  whiteSpace: "nowrap",
                }}
              >
                Language
              </span>

              <select
                className="all-songs-language-select"
                value={language}
                onChange={(event) => setLanguage(event.target.value)}
                aria-label="Filter songs by language"
                style={{
                  minWidth: "145px",
                  maxWidth: "100%",
                  padding: "11px 36px 11px 13px",
                  borderRadius: "12px",
                  border: "1px solid rgba(212, 175, 55, 0.38)",
                  background: "#101d35",
                  color: "#f5f7fb",
                  fontSize: "14px",
                  fontWeight: 600,
                  cursor: "pointer",
                  outline: "none",
                }}
              >
                {LANGUAGES.map((item) => (
                  <option
                    key={item.value}
                    value={item.value}
                    style={{
                      background: "#101d35",
                      color: "#f5f7fb",
                    }}
                  >
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>



        {/* LOADING */}

        {loading ? (

          <div
            className="all-songs-loading"
            role="status"
          >

            <FaMusic className="all-songs-loading-icon" />

            <h2>{languageText.loadingTitle}</h2>

            <p>
              Please wait while we prepare your songs.
            </p>

          </div>

        ) : error ? (

          /* ERROR */

          <div
            className="all-songs-error"
            role="alert"
          >

            <p>{error}</p>

            <button
              type="button"
              onClick={loadSongs}
            >
              Try Again
            </button>

          </div>

        ) : filteredSongs.length === 0 ? (

          /* EMPTY STATE */

          <div className="all-songs-empty">

            <FaMusic className="all-songs-empty-icon" />

            <h2>{languageText.emptyTitle}</h2>

            <p>{languageText.emptyMessage}</p>

            {(search || language !== "All") && (

              <button
                type="button"
                className="all-songs-reset-search"
                onClick={() => {
                  setSearch("");
                  setLanguage("All");
                }}
              >
                {languageText.clearFilters}
              </button>

            )}

          </div>

        ) : (

          /* SONG LIST */

          <div className="all-songs-list">

            {filteredSongs.map((song, songIndex) => {

              const songId = getSongId(song);

              const isCurrent =
                currentSongId === songId;

              const playing =
                isCurrent && isPlaying;

              const liked = Boolean(
                isLiked?.(songId)
              );

              const albumName = getAlbumName(song);

              // Use only the song's actual uploaded cover.
              // No default/fallback cover is displayed.
              let cover = "";

              try {
                cover = getSongCover(song) || "";
              } catch {
                cover = "";
              }

              const shouldShowNativeAd =
                nativeAdsReady &&
                (songIndex + 1) % NATIVE_AD_INTERVAL === 0 &&
                (songIndex + 1) / NATIVE_AD_INTERVAL <=
                  MAX_NATIVE_AD_SLOTS;

              const nativeAdSlot = shouldShowNativeAd
                ? createElement(
                    "capacitor-admob-native",
                    {
                      "feed-id": NATIVE_AD_FEED_ID,
                      "slot-key": `sponsored-after-song-${songId}`,
                    }
                  )
                : null;

              return (
                <Fragment key={songId}>

                <article
                  className={`all-song-card ${
                    isCurrent ? "current" : ""
                  }`}
                >

                  {/* SONG COVER */}

                  <button
                    type="button"
                    className="all-song-cover"
                    onClick={() => handlePlay(song)}
                    aria-label={`${
                      playing ? "Pause" : "Play"
                    } ${getSongTitle(song)}`}
                  >

                    {cover && (
                      <img
                        src={cover}
                        alt={`${getSongTitle(song)} cover`}
                        loading="lazy"
                        onError={(event) => {
                          event.currentTarget.onerror = null;
                          event.currentTarget.style.display = "none";
                        }}
                      />
                    )}

                    <span className="all-song-cover-play">

                      {playing ? (
                        <FaPause />
                      ) : (
                        <FaPlay />
                      )}

                    </span>

                  </button>

                  {/* SONG DETAILS */}

                  <div className="all-song-card-info">

                    <button
                      type="button"
                      className="all-song-info"
                      onClick={() => handlePlay(song)}
                      title={getSongTitle(song)}
                    >

                      {(() => {
                        const displayTitles = getSongDisplayTitles(song);

                        return (
                          <>
                            <span className="all-song-primary-title">
                              {displayTitles.primary}
                            </span>

                            {displayTitles.secondary && (
                              <span className="all-song-english-title">
                                {displayTitles.secondary}
                              </span>
                            )}
                          </>
                        );
                      })()}

                      <span className="all-song-artist">
                        {getArtistName(song, artistsById)}
                      </span>

                    </button>

                  </div>

                  {/* THREE-DOT MENU */}

                  <div
                    className="all-song-menu-container"
                    ref={
                      menuSongId === songId
                        ? menuRef
                        : null
                    }
                  >

                    <button
                      type="button"
                      className="all-song-menu-trigger"
                      aria-label={`More options for ${getSongTitle(song)}`}
                      aria-haspopup="menu"
                      aria-expanded={
                        menuSongId === songId
                      }
                      onClick={() =>
                        setMenuSongId((current) =>
                          current === songId
                            ? null
                            : songId
                        )
                      }
                    >
                      <FaEllipsisV />
                    </button>

                    {menuSongId === songId && (

                      <div
                        className="all-song-context-menu"
                        role="menu"
                        aria-label={`Options for ${getSongTitle(song)}`}
                      >

                        {/* PLAY NOW */}

                        <button
                          type="button"
                          role="menuitem"
                          onClick={() => {
                            handlePlay(song);
                            setMenuSongId(null);
                          }}
                        >
                          <FaPlay />
                          <span>Play Now</span>
                        </button>

                        {/* PLAY NEXT */}

                        <button
                          type="button"
                          role="menuitem"
                          onClick={() =>
                            handlePlayNext(song)
                          }
                        >
                          <FaStepForward />
                          <span>Play Next</span>
                        </button>

                        {/* ADD TO QUEUE */}

                        <button
                          type="button"
                          role="menuitem"
                          onClick={() =>
                            handleAddToQueue(song)
                          }
                        >
                          <FaPlus />
                          <span>Add to Queue</span>
                        </button>

                        <div className="all-song-menu-divider" />

                        {/* LIKE / UNLIKE */}

                        <button
                          type="button"
                          role="menuitem"
                          onClick={() =>
                            handleToggleLike(song)
                          }
                        >

                          {liked ? (
                            <FaHeart />
                          ) : (
                            <FaRegHeart />
                          )}

                          <span>
                            {liked
                              ? "Remove from Liked Songs"
                              : "Add to Liked Songs"}
                          </span>

                        </button>

                        {/* PLAYLIST */}

                        <button
                          type="button"
                          role="menuitem"
                          onClick={() =>
                            handleAddToPlaylist(song)
                          }
                        >
                          <FaListUl />
                          <span>Add to Playlist</span>
                        </button>

                        {/* ALBUM */}

                        {albumName && (

                          <>

                            <div className="all-song-menu-divider" />

                            <button
                              type="button"
                              role="menuitem"
                              onClick={() =>
                                handleViewAlbum(song)
                              }
                            >
                              <FaCompactDisc />
                              <span>View Album</span>
                            </button>

                          </>

                        )}

                      </div>

                    )}

                  </div>

                </article>

                {nativeAdSlot && (
                  <section
                    className="keerthana-native-ad-slot"
                    aria-label="Sponsored content"
                    style={{
                      width: "100%",
                      minHeight: "350px",
                      height: "350px",
                      margin: "18px 0",
                      padding: "10px",
                      boxSizing: "border-box",
                      overflow: "hidden",
                      borderRadius: "14px",
                      background: "rgba(16, 29, 53, 0.45)",
                    }}
                  >
                    <div
                      style={{
                        marginBottom: "6px",
                        color: "var(--text-secondary, #aebbd0)",
                        fontSize: "11px",
                        fontWeight: 700,
                        letterSpacing: "0.08em",
                        textTransform: "uppercase",
                      }}
                    >
                      Sponsored
                    </div>
                    <div
                      style={{
                        width: "100%",
                        height: "320px",
                        minHeight: "320px",
                      }}
                    >
                      {nativeAdSlot}
                    </div>
                  </section>
                )}

                </Fragment>
              );

            })}

          </div>

        )}

      </section>

      {/* TOAST */}

      {notice && (

        <div
          className="all-songs-toast"
          role="status"
        >
          {notice}
        </div>

      )}

    </main>
  );
}
