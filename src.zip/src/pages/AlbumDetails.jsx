
import { useCallback, useEffect, useRef, useState } from "react";

import {
  FaArrowLeft,
  FaCompactDisc,
  FaEllipsisV,
  FaPause,
  FaPlay,
  FaPlus,
  FaTimes,
} from "react-icons/fa";

import { useNavigate, useParams } from "react-router-dom";

import API from "../services/api";
import { usePlayer } from "../context/usePlayer";

import {
  getAlbumCover,
  
} from "../utils/media";

import VoiceSearch from "../components/VoiceSearch";

import "../assets/css/albumDetails.css";

function getAlbumEnglishTitle(album) {
  return album?.title_english || album?.title || album?.title_telugu || "Untitled Album";
}
function getAlbumTeluguTitle(album) {
  const telugu = album?.title_telugu || "";
  return telugu && telugu.trim() !== getAlbumEnglishTitle(album).trim() ? telugu : "";
}
function isEnglishArtistName(value) {
  if (typeof value !== "string") return false;
  const name = value.trim();
  if (!name) return false;
  return !/[\u0C00-\u0C7F]/.test(name);
}

function getSongsArray(response) {
  const payload = response?.data;
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.songs)) return payload.songs;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.data?.songs)) return payload.data.songs;
  return [];
}

function mergeSongArtistRelationships(album, catalogSongs) {
  if (!album || !Array.isArray(album.songs)) return album;

  const catalogById = new Map(
    catalogSongs.map((song) => [
      String(song?.id ?? song?.song_id),
      song,
    ])
  );

  return {
    ...album,
    songs: album.songs.map((song) => {
      const catalogSong = catalogById.get(
        String(song?.id ?? song?.song_id)
      );

      if (!catalogSong) return song;

      return {
        ...catalogSong,
        ...song,
        // Prefer the complete many-to-many relationships from /songs.
        artists: Array.isArray(catalogSong.artists) && catalogSong.artists.length
          ? catalogSong.artists
          : song.artists,
        song_artists: Array.isArray(catalogSong.song_artists) && catalogSong.song_artists.length
          ? catalogSong.song_artists
          : song.song_artists,
        artist_ids: Array.isArray(catalogSong.artist_ids) && catalogSong.artist_ids.length
          ? catalogSong.artist_ids
          : song.artist_ids,
      };
    }),
  };
}

function getArtistEntries(source, artistsById = {}) {
  const candidates = [
    ...(Array.isArray(source?.artists) ? source.artists : []),
    ...(Array.isArray(source?.song_artists) ? source.song_artists : []),
    ...(Array.isArray(source?.artist) ? source.artist : []),
    ...(source?.artist && !Array.isArray(source.artist) && typeof source.artist === "object"
      ? [source.artist]
      : []),
  ];

  if (!candidates.length && Array.isArray(source?.artist_ids)) {
    candidates.push(...source.artist_ids);
  }

  if (!candidates.length) {
    const legacyId = source?.artist_id ?? source?.artistId;
    if (legacyId != null) candidates.push(legacyId);
  }

  const entries = [];

  const addEntry = (artist, fallbackId = null) => {
    if (artist == null) return;

    const nestedArtist =
      typeof artist === "object"
        ? artist.artist || artist.artist_details || artist.artistDetails || artist
        : null;

    const artistId =
      typeof artist === "object"
        ? artist.artist_id ?? artist.id ?? nestedArtist?.artist_id ?? nestedArtist?.id ?? fallbackId
        : /^\d+$/.test(String(artist).trim())
          ? artist
          : fallbackId;

    const linkedArtist =
      artistId != null ? artistsById[String(artistId)] || {} : {};

    const name =
      typeof artist === "string" && artistId == null
        ? artist
        : nestedArtist?.name_english ||
          nestedArtist?.english_name ||
          nestedArtist?.artist_name_english ||
          nestedArtist?.nameEnglish ||
          nestedArtist?.englishName ||
          artist?.name_english ||
          artist?.english_name ||
          artist?.artist_name_english ||
          artist?.nameEnglish ||
          artist?.englishName ||
          linkedArtist.name_english ||
          linkedArtist.english_name ||
          linkedArtist.artist_name_english ||
          linkedArtist.nameEnglish ||
          linkedArtist.englishName ||
          artist?.artist_name ||
          artist?.name;

    if (!isEnglishArtistName(name)) return;

    entries.push({
      id: artistId ?? linkedArtist.id ?? null,
      name: name.trim(),
    });
  };

  candidates.forEach((candidate) => addEntry(candidate));

  if (!entries.length) {
    addEntry(
      source?.artist_name_english ||
        source?.artistNameEnglish ||
        source?.artist_english ||
        source?.artist_name ||
        (typeof source?.artist === "string" ? source.artist : ""),
      source?.artist_id ?? source?.artistId
    );
  }

  const seen = new Set();
  return entries.filter((artist) => {
    const key = artist.name.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function getAlbumArtistEntries(album, artistsById = {}) {
  const entries = getArtistEntries(album, artistsById);
  return entries.length ? entries : [];
}

function getSongArtistNames(song, artistsById = {}) {
  const entries = getArtistEntries(song, artistsById);
  return entries.length
    ? entries.map((artist) => artist.name).join(", ")
    : "Unknown Artist";
}

function getSongEnglishTitle(song) {
  return song?.title_english || song?.title || song?.title_telugu || "Untitled song";
}
function getSongTeluguTitle(song) {
  const telugu = song?.title_telugu || song?.title || "";
  return telugu && telugu.trim() !== getSongEnglishTitle(song).trim() ? telugu : "";
}
function compareSongsAlphabetically(a, b) {
  return getSongEnglishTitle(a).localeCompare(getSongEnglishTitle(b), "en", {
    sensitivity: "base",
    numeric: true,
  });
}

function AlbumDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const {
    playSong,
    togglePlay,
    currentSong,
    isPlaying,
    addToQueue,
  } = usePlayer();

  const [album, setAlbum] = useState(null);
  const [artistsById, setArtistsById] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [openMenuId, setOpenMenuId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [voiceLanguage, setVoiceLanguage] = useState("te-IN");

  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);

  const requestVersionRef = useRef(0);
  const requestInProgressRef = useRef(false);
  const albumRef = useRef(album);
  albumRef.current = album;
  const touchStartYRef = useRef(null);
  const pullDistanceRef = useRef(0);

  /* =====================================================
     VOICE SEARCH
  ===================================================== */

  const handleVoiceSearch = (recognizedText) => {
    setSearchQuery(recognizedText);
  };

  /* =====================================================
     LOAD / REFRESH ALBUM
  ===================================================== */

  const loadAlbum = useCallback(async ({ silent = false } = {}) => {
    if (!id || requestInProgressRef.current) return;

    requestInProgressRef.current = true;
    const requestVersion = ++requestVersionRef.current;

    if (silent) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }
    setError("");

    try {
      const response = await API.get(`/albums/${id}`);
      if (requestVersion === requestVersionRef.current) {
        let loadedAlbum = response?.data?.album || response?.data || null;

        if (!loadedAlbum) {
          setAlbum(null);
          setError("Album not found");
        } else {
          // Album endpoints may return only the legacy single artist.
          // Merge song-level many-to-many artist links from the full songs API.
          try {
            const songsResponse = await API.get("/songs");
            loadedAlbum = mergeSongArtistRelationships(
              loadedAlbum,
              getSongsArray(songsResponse)
            );
          } catch (songsError) {
            console.warn(
              "Could not load complete song artist relationships:",
              songsError
            );
          }

          if (requestVersion === requestVersionRef.current) {
            setAlbum(loadedAlbum);
          }
        }

        // Resolve artist IDs when album/song payloads do not include English names.
        try {
          const artistsResponse = await API.get("/artists");
          const payload = artistsResponse?.data;
          const artistList = Array.isArray(payload)
            ? payload
            : Array.isArray(payload?.artists)
              ? payload.artists
              : Array.isArray(payload?.data)
                ? payload.data
                : Array.isArray(payload?.data?.artists)
                  ? payload.data.artists
                  : [];
          const lookup = {};
          artistList.forEach((item) => {
            const artistId = item?.id ?? item?.artist_id;
            const englishName =
              item?.name_english ||
              item?.english_name ||
              item?.artist_name_english ||
              item?.nameEnglish ||
              item?.englishName;
            if (artistId != null && isEnglishArtistName(englishName)) {
              lookup[String(artistId)] = {
                ...item,
                name_english: englishName.trim(),
              };
            }
          });
          if (requestVersion === requestVersionRef.current) {
            setArtistsById(lookup);
          }
        } catch (artistError) {
          console.warn("Could not load artist lookup for album:", artistError);
        }
      }
    } catch (err) {
      console.error("Album error:", err);
      if (requestVersion === requestVersionRef.current) {
        setError((previousError) =>
          silent && albumRef.current
            ? previousError
            : (err.response?.data?.message || "Unable to load album")
        );
      }
    } finally {
      if (requestVersion === requestVersionRef.current) {
        requestInProgressRef.current = false;
        setLoading(false);
        setRefreshing(false);
        pullDistanceRef.current = 0;
        setPullDistance(0);
      }
    }
  }, [id]);

  useEffect(() => {
    if (!id) {
      setError("Album ID is missing.");
      setLoading(false);
      return undefined;
    }

    loadAlbum();

    return () => {
      requestVersionRef.current += 1;
      requestInProgressRef.current = false;
    };
  }, [id, loadAlbum]);

  useEffect(() => {
    const handleAppResume = () => {
      if (document.visibilityState === "hidden") return;
      loadAlbum({ silent: true });
    };

    window.addEventListener("keerthana:app-resume", handleAppResume);
    return () => window.removeEventListener("keerthana:app-resume", handleAppResume);
  }, [loadAlbum]);

  /* =====================================================
     PULL DOWN TO REFRESH
  ===================================================== */

  const handleTouchStart = (event) => {
    if (window.scrollY <= 0 && event.touches?.length === 1 && !loading && !refreshing) {
      touchStartYRef.current = event.touches[0].clientY;
      pullDistanceRef.current = 0;
    } else {
      touchStartYRef.current = null;
    }
  };

  const handleTouchMove = (event) => {
    if (touchStartYRef.current === null || window.scrollY > 0 || loading || refreshing) return;

    const currentY = event.touches?.[0]?.clientY;
    if (typeof currentY !== "number") return;

    const distance = Math.max(0, Math.min((currentY - touchStartYRef.current) * 0.55, 90));
    pullDistanceRef.current = distance;
    setPullDistance(distance);
  };

  const handleTouchEnd = () => {
    touchStartYRef.current = null;
    const shouldRefresh = pullDistanceRef.current >= 65;
    pullDistanceRef.current = 0;
    setPullDistance(0);
    if (shouldRefresh) loadAlbum({ silent: true });
  };

  const handleTouchCancel = () => {
    touchStartYRef.current = null;
    pullDistanceRef.current = 0;
    setPullDistance(0);
  };

  /* =====================================================
     LOADING STATE
  ===================================================== */

  if (loading) {
    return (
      <div className="album-details-page album-details-loading">
        <div className="album-details-loader" />
        <p>Loading album...</p>
      </div>
    );
  }

  /* =====================================================
     ERROR STATE
  ===================================================== */

  if (error || !album) {
    return (
      <div className="album-details-page album-details-error">
        <button
          type="button"
          className="album-details-back"
          onClick={() => navigate("/albums")}
        >
          <FaArrowLeft />
          Back to Albums
        </button>

        <p>{error || "Album not found"}</p>
        <button
          type="button"
          className="album-details-back"
          onClick={() => loadAlbum()}
        >
          Try Again
        </button>
      </div>
    );
  }

  /* =====================================================
     ALBUM DATA & SEARCH
  ===================================================== */

  const songs = Array.isArray(album.songs)
    ? [...album.songs].sort(compareSongsAlphabetically)
    : [];

  const albumEnglishTitle = getAlbumEnglishTitle(album);
  const albumTeluguTitle = getAlbumTeluguTitle(album);
  const albumArtistEntries = getAlbumArtistEntries(album, artistsById);

  const cover = getAlbumCover(album);

  const query = searchQuery.trim().toLowerCase();

  const filteredSongs = songs
    .filter((song) => {
      if (!query) return true;

      const searchableFields = [
        song?.title,
        song?.title_english,
        song?.title_telugu,
        song?.artist_name,
        song?.artist_name_english,
        song?.artist_name_telugu,
        ...getArtistEntries(song, artistsById).map((artist) => artist.name),
      ];

      return searchableFields.some((field) =>
        String(field || "").toLowerCase().includes(query)
      );
    })
    .sort(compareSongsAlphabetically);

  const isAlbumSong = (song) =>
    songs.some(
      (albumSong) =>
        String(albumSong.id) === String(song?.id)
    );

  /* =====================================================
     FORMAT DURATION
  ===================================================== */

  const formatDuration = (value) => {
    if (value == null || value === "") return "";

    if (typeof value === "string" && value.includes(":")) {
      return value;
    }

    const seconds = Number(value);

    if (!Number.isFinite(seconds) || seconds < 0) {
      return "";
    }

    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);

    return `${mins}:${String(secs).padStart(2, "0")}`;
  };

  /* =====================================================
     PLAY ALL — COMPLETE ALBUM
  ===================================================== */

  const handleAlbumPlayPause = async () => {
    if (!songs.length) return;

    try {
      if (currentSong && isAlbumSong(currentSong)) {
        await togglePlay();
        return;
      }

      await playSong(songs[0], songs);
    } catch (err) {
      console.error("Album playback error:", err);
    }
  };

  /* =====================================================
     PLAY / PAUSE TRACK
  ===================================================== */

  const handleSongPlayPause = async (song) => {
    setOpenMenuId(null);

    try {
      if (String(currentSong?.id) === String(song.id)) {
        await togglePlay();
        return;
      }

      await playSong(song, songs);
    } catch (err) {
      console.error("Song playback error:", err);
    }
  };

  /* =====================================================
     ADD TO QUEUE
  ===================================================== */

  const handleAddToQueue = async (song) => {
    setOpenMenuId(null);

    if (typeof addToQueue !== "function") {
      console.warn(
        "addToQueue is not available in usePlayer()."
      );
      return;
    }

    try {
      await addToQueue(song);
    } catch (err) {
      console.error("Add to queue error:", err);
    }
  };

  /* =====================================================
     ADD TO PLAYLIST
  ===================================================== */

  const handleAddToPlaylist = (song) => {
    setOpenMenuId(null);

    navigate("/playlists", {
      state: {
        selectedSong: song,
        action: "add-song",
      },
    });
  };

  const albumIsPlaying = Boolean(
    currentSong &&
      isPlaying &&
      isAlbumSong(currentSong)
  );

  /* =====================================================
     PAGE
  ===================================================== */

  return (
    <div
      className="album-details-page"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchCancel}
    >
      {(refreshing || pullDistance > 0) && (
        <>
          <style>{`@keyframes albumDetailsRefreshSpin { to { transform: rotate(360deg); } }`}</style>
          <div
            className="album-details-refresh-indicator"
            role="status"
            aria-live="polite"
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "9px",
              minHeight: "38px",
              color: "#e8c96a",
              fontSize: "13px",
              fontWeight: 600,
              transform: `translateY(${Math.min(pullDistance, 65) * 0.25}px)`,
            }}
          >
            <span
              aria-hidden="true"
              style={{
                width: "15px",
                height: "15px",
                border: "2px solid rgba(232, 201, 106, 0.28)",
                borderTopColor: "#e8c96a",
                borderRadius: "50%",
                display: "inline-block",
                animation: refreshing ? "albumDetailsRefreshSpin 0.8s linear infinite" : "none",
              }}
            />
            {refreshing ? "Refreshing album..." : "Pull down to refresh"}
          </div>
        </>
      )}

      {/* BACK NAVIGATION */}

      <button
        type="button"
        className="album-details-back"
        onClick={() => navigate(-1)}
      >
        <FaArrowLeft />
        Back
      </button>

      {/* ALBUM HEADER */}

      <section className="album-details-hero">
        <div className="album-details-cover">
          {cover ? (
            <img
              src={cover}
              alt={`${albumEnglishTitle} album cover`}
              onError={(event) => {
                event.currentTarget.style.display = "none";
              }}
            />
          ) : (
            <FaCompactDisc />
          )}
        </div>

        <div className="album-details-info">
          <span className="album-details-label">
            ALBUM
          </span>

          <div className="album-details-title-names">
            <h1>{albumEnglishTitle}</h1>
            {albumTeluguTitle && (
              <p className="album-details-telugu-title">{albumTeluguTitle}</p>
            )}
          </div>

          <div className="album-details-artist">
            <span className="album-details-artist-names">
              {albumArtistEntries.map((artist, index) => (
                <span key={`${artist.id || artist.name}-${index}`}>
                  {artist.id ? (
                    <button
                      type="button"
                      onClick={() => navigate(`/artists/${artist.id}`)}
                      className="album-details-artist-link"
                    >
                      {artist.name}
                    </button>
                  ) : (
                    artist.name
                  )}
                  {index < albumArtistEntries.length - 1 ? ", " : ""}
                </span>
              ))}
            </span>
          </div>
        </div>
      </section>

      {/* PLAY ALL — ALWAYS USES FULL ALBUM */}

      <div className="album-details-actions">
        <button
          type="button"
          className="album-details-play-all"
          onClick={handleAlbumPlayPause}
          disabled={!songs.length}
        >
          {albumIsPlaying ? <FaPause /> : <FaPlay />}

          <span>
            {albumIsPlaying ? "Pause Album" : "Play All"}
          </span>
        </button>
      </div>

      {/* SONG LIST */}

      <section className="album-details-song-section">
        <div className="album-details-list-heading">
          <div>
            <span className="album-details-list-eyebrow">
              YOUR WORSHIP COLLECTION
            </span>

            <h2>
              {query ? "Search Results" : "Tracks"}
            </h2>
          </div>

          <span className="album-details-track-count">
            {query
              ? filteredSongs.length
              : songs.length}{" "}
            {query
              ? filteredSongs.length === 1
                ? "MATCH"
                : "MATCHES"
              : songs.length === 1
                ? "TRACK"
                : "TRACKS"}
          </span>
        </div>

        {/* VOICE SEARCH */}

        <section
          className="album-details-voice-search-section"
          aria-label="Search tracks in this album"
        >
          <VoiceSearch
            value={searchQuery}
            onChange={setSearchQuery}
            onSearch={handleVoiceSearch}
            language={voiceLanguage}
            onLanguageChange={setVoiceLanguage}
            placeholder="Search songs and artists..."
            ariaLabel="Search tracks in this album"
          />
        </section>

        {/* SEARCH SUMMARY */}

        {query && (
          <p
            className="album-details-search-summary"
            aria-live="polite"
          >
            {filteredSongs.length}{" "}
            {filteredSongs.length === 1
              ? "song"
              : "songs"}{" "}
            found
          </p>
        )}

        {/* FILTERED TRACK LIST */}

        {filteredSongs.length > 0 && (
          <div
            className="album-details-song-list"
            id="album-details-song-list"
          >
            {filteredSongs.map((song, index) => {
              const isCurrent =
                String(currentSong?.id) === String(song.id);

              const isCurrentlyPlaying =
                isCurrent && isPlaying;

              const duration = formatDuration(song.duration);

              return (
                <article
                  className={`album-details-song-row ${
                    isCurrent ? "is-current" : ""
                  }`}
                  key={song.id}
                >
                  {/* PLAY / PAUSE */}

                  <button
                    type="button"
                    className="album-details-track-number"
                    onClick={() => handleSongPlayPause(song)}
                    aria-label={
                      isCurrentlyPlaying
                        ? `Pause ${song.title || "song"}`
                        : `Play ${song.title || "song"}`
                    }
                    title={
                      isCurrentlyPlaying
                        ? "Pause song"
                        : "Play song"
                    }
                  >
                    {isCurrentlyPlaying ? (
                      <FaPause />
                    ) : (
                      <FaPlay />
                    )}
                  </button>

                  {/* TRACK COVER */}

                  <button
                    type="button"
                    className="album-details-track-art"
                    onClick={() => handleSongPlayPause(song)}
                    aria-label={`Play ${
                      song.title || "song"
                    }`}
                  >
                    {song.cover_url || cover ? (
                      <img
                        src={song.cover_url || cover}
                        alt=""
                        onError={(event) => {
                          event.currentTarget.style.display = "none";
                        }}
                      />
                    ) : (
                      <FaCompactDisc aria-hidden="true" />
                    )}
                  </button>

                  {/* TRACK DETAILS */}

                  <button
                    type="button"
                    className="album-details-track-main"
                    onClick={() => handleSongPlayPause(song)}
                  >
                    <strong title={getSongEnglishTitle(song)}>
                      {getSongEnglishTitle(song)}
                    </strong>

                    {getSongTeluguTitle(song) && (
                      <span className="album-details-track-telugu-title">
                        {getSongTeluguTitle(song)}
                      </span>
                    )}

                    <span>
                      {getSongArtistNames(song, artistsById)}
                    </span>
                  </button>

                  {/* DURATION */}

                  <span className="album-details-track-duration">
                    {duration}
                  </span>

                  {/* THREE-DOT MENU */}

                  <div className="album-details-track-menu-wrap">
                    <button
                      type="button"
                      className="album-details-more-button"
                      aria-label={`More options for ${
                        song.title || "song"
                      }`}
                      aria-haspopup="true"
                      aria-expanded={openMenuId === song.id}
                      onClick={() =>
                        setOpenMenuId((previous) =>
                          previous === song.id
                            ? null
                            : song.id
                        )
                      }
                    >
                      <FaEllipsisV />
                    </button>

                    {openMenuId === song.id && (
                      <>
                        <button
                          type="button"
                          className="album-details-menu-backdrop"
                          aria-label="Close song menu"
                          onClick={() => setOpenMenuId(null)}
                        />

                        <div className="album-details-song-menu">
                          <button
                            type="button"
                            onClick={() =>
                              handleSongPlayPause(song)
                            }
                          >
                            {isCurrentlyPlaying ? (
                              <FaPause />
                            ) : (
                              <FaPlay />
                            )}

                            <span>
                              {isCurrentlyPlaying
                                ? "Pause"
                                : "Play"}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              handleAddToQueue(song)
                            }
                          >
                            <FaPlus />
                            <span>Add to queue</span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              handleAddToPlaylist(song)
                            }
                          >
                            <FaCompactDisc />
                            <span>Add to playlist</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* EMPTY / NO MATCHES */}

        {!filteredSongs.length && (
          <div className="album-details-empty">
            <FaCompactDisc />

            <h2>
              {query
                ? "No Matching Songs"
                : "No Songs Yet"}
            </h2>

            <p>
              {query
                ? "Try another song title or artist."
                : "Songs added to this album will appear here."}
            </p>

            {query && (
              <button
                type="button"
                className="album-details-reset-search"
                onClick={() => setSearchQuery("")}
              >
                <FaTimes />
                Clear Search
              </button>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

export default AlbumDetails;
