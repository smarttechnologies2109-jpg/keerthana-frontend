
import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import { useNavigate, useParams } from "react-router-dom";

import {
  FaArrowLeft,
  FaMusic,
  FaRedo,
  FaThLarge,
  FaPlay,
  FaPause,
  FaEllipsisV,
  FaPlus,
  FaListUl,
  FaTimes,
} from "react-icons/fa";

import API from "../services/api";
import Sidebar from "../components/Sidebar";
import { usePlayer } from "../context/usePlayer";
import { getMediaUrl } from "../utils/media";

import "../assets/css/categoryDetails.css";

/* =========================================================
   KEERTHANA MUSIC — CATEGORY DETAILS

   API:
   GET /api/categories/:id
   GET /api/songs

   Features:
   - Loads category information and actual song records
   - Filters songs using category_id
   - Displays horizontal song rows
   - Plays songs through the shared player
   - Supports queue and playlist actions
   - Shows loading, error and empty states
========================================================= */

/* =========================================================
   BILINGUAL CATEGORY AND SONG TITLE HELPERS
========================================================= */

const getCategoryEnglishName = (item) => {
  const english = String(item?.name_english || "").trim();
  const legacy = String(item?.name || "").trim();
  const telugu = String(item?.name_telugu || "").trim();

  if (english) return english;
  if (legacy && legacy !== telugu) return legacy;
  return telugu || legacy || "Music Category";
};

const getCategoryTeluguName = (item) => {
  const telugu = String(item?.name_telugu || "").trim();
  const englishName = getCategoryEnglishName(item);
  const legacy = String(item?.name || "").trim();

  if (telugu && telugu !== englishName) return telugu;
  if (legacy && legacy !== englishName) return legacy;
  return "";
};

const hasTeluguScript = (value) => /[\u0C00-\u0C7F]/.test(String(value || ""));

const getSongEnglishTitle = (song) => {
  const candidates = [
    song?.title_english,
    song?.titleEnglish,
    song?.english_title,
    song?.englishTitle,
    song?.title,
    song?.name,
  ];

  const english = candidates.find(
    (value) =>
      typeof value === "string" &&
      value.trim() &&
      !hasTeluguScript(value)
  );

  return String(english || "Untitled song").trim();
};

const getSongTeluguTitle = (song) => {
  const candidates = [
    song?.title_telugu,
    song?.titleTelugu,
    song?.title_native,
    song?.title,
    song?.name,
  ];

  const telugu = candidates.find(
    (value) =>
      typeof value === "string" &&
      value.trim() &&
      hasTeluguScript(value)
  );

  return String(telugu || "").trim();
};

const getSongEnglishArtistName = (song, artists = []) => {
  const isEnglishName = (value) =>
    typeof value === "string" &&
    value.trim() &&
    !hasTeluguScript(value);

  const artistDirectory = Array.isArray(artists) ? artists : [];
  const names = [];

  const addName = (value) => {
    if (!isEnglishName(value)) return;

    const name = value.trim();
    if (!names.some((existing) => existing.toLowerCase() === name.toLowerCase())) {
      names.push(name);
    }
  };

  const findDirectoryArtist = (artistId) => {
    if (artistId == null) return null;
    return artistDirectory.find(
      (item) =>
        String(item?.id ?? item?.artist_id ?? "") === String(artistId)
    ) || null;
  };

  const addArtist = (artist) => {
    if (artist == null) return;

    if (typeof artist === "string" || typeof artist === "number") {
      const directoryArtist = findDirectoryArtist(artist);
      if (directoryArtist) {
        addArtist(directoryArtist);
      } else if (typeof artist === "string") {
        addName(artist);
      }
      return;
    }

    if (typeof artist !== "object") return;

    // song_artists rows may wrap the actual artist object in `artist`.
    const nestedArtist =
      artist.artist && typeof artist.artist === "object"
        ? artist.artist
        : artist.artist_details && typeof artist.artist_details === "object"
          ? artist.artist_details
          : artist;

    addName(
      nestedArtist.name_english ||
      nestedArtist.english_name ||
      nestedArtist.nameEnglish ||
      nestedArtist.englishName ||
      nestedArtist.artist_name_english ||
      nestedArtist.artist_english
    );

    const artistId =
      nestedArtist.id ??
      nestedArtist.artist_id ??
      artist.artist_id ??
      artist.artistId;

    const directoryArtist = findDirectoryArtist(artistId);
    if (directoryArtist) {
      addName(
        directoryArtist.name_english ||
        directoryArtist.english_name ||
        directoryArtist.nameEnglish ||
        directoryArtist.englishName ||
        directoryArtist.artist_name_english
      );
    }
  };

  // Support the common multi-artist response formats.
  if (Array.isArray(song?.artists)) song.artists.forEach(addArtist);
  if (Array.isArray(song?.song_artists)) song.song_artists.forEach(addArtist);

  if (Array.isArray(song?.artist)) {
    song.artist.forEach(addArtist);
  } else {
    addArtist(song?.artist);
  }

  // Resolve artist IDs returned separately from artist objects.
  const artistIds = [
    ...(Array.isArray(song?.artist_ids) ? song.artist_ids : []),
    ...(Array.isArray(song?.artistIds) ? song.artistIds : []),
  ];
  artistIds.forEach(addArtist);

  // Backward compatibility with the original single-artist fields.
  const legacyArtistId = song?.artist_id ?? song?.artistId;
  if (legacyArtistId != null) addArtist(legacyArtistId);

  [
    song?.artist_name_english,
    song?.artist_english,
    song?.artist_english_name,
    song?.artist_name_en,
    song?.artistEnglish,
    song?.artistEnglishName,
    song?.artistNameEnglish,
    song?.artist_name,
    song?.artistName,
  ].forEach(addName);

  return names.length ? names.join(", ") : "Artist name unavailable";
};


const compareSongsAlphabetically = (a, b) => {
  const titleA = a?.title_english || a?.title || "";
  const titleB = b?.title_english || b?.title || "";

  return String(titleA).localeCompare(String(titleB), "en", {
    sensitivity: "base",
    numeric: true,
  });
};


const getCategoryCoverUrl = (item) => {
  const imagePath =
    item?.image_url ||
    item?.imageUrl ||
    item?.cover_url ||
    item?.coverUrl ||
    item?.image ||
    item?.photo;

  if (!imagePath || typeof imagePath !== "string") return "";

  try {
    return getMediaUrl(imagePath) || "";
  } catch (error) {
    console.error("Category detail cover URL error:", error);
    return "";
  }
};

function CategoryDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const menuRef = useRef(null);

  const {
    playSong,
    togglePlay,
    currentSong,
    isPlaying,
    addToQueue,
  } = usePlayer();

  const [category, setCategory] = useState(null);
  const [songs, setSongs] = useState([]);
  const [artists, setArtists] = useState([]);

  const [loading, setLoading] = useState(true);
  const [songsLoading, setSongsLoading] = useState(true);

  const [error, setError] = useState("");
  const [songsError, setSongsError] = useState("");

  const [activeMenu, setActiveMenu] = useState(null);
  const [notice, setNotice] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  // Refresh state is separate from the initial loading states so existing
  // category content stays visible during background updates.
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const categoryRequestRef = useRef(false);
  const songsRequestRef = useRef(false);
  const categoryRef = useRef(category);
  const songsRef = useRef(songs);
  categoryRef.current = category;
  songsRef.current = songs;
  const touchStartYRef = useRef(null);
  const pullDistanceRef = useRef(0);

  /* =========================================================
     LOAD CATEGORY DETAILS
  ========================================================= */

  const loadCategory = useCallback(async ({ silent = false } = {}) => {
    if (!id) {
      setCategory(null);
      setError("A category ID was not provided.");
      setLoading(false);
      return;
    }

    if (categoryRequestRef.current) return;

    categoryRequestRef.current = true;

    try {
      if (!silent) {
        setLoading(true);
        setError("");
        if (!categoryRef.current) setCategory(null);
      }

      const response = await API.get(
        `/categories/${encodeURIComponent(id)}`
      );

      const data = response.data;

      if (data?.success === false) {
        throw new Error(
          data?.message || "Unable to load category."
        );
      }

      const categoryData =
        data?.category ||
        data?.data?.category ||
        data?.data ||
        null;

      if (
        !categoryData ||
        categoryData.id === undefined ||
        categoryData.id === null
      ) {
        throw new Error("Category details were not found.");
      }

      setCategory(categoryData);
      if (!silent) setError("");
    } catch (err) {
      console.error("Load category details error:", err);

      // Keep previously loaded category data during silent refresh failures.
      if (!silent || !category) {
        if (!categoryRef.current) setCategory(null);
        setError(
          err?.response?.status === 404
            ? "This category could not be found."
            : err?.response?.data?.message ||
                err?.message ||
                "Unable to load this category. Please try again."
        );
      }
    } finally {
      categoryRequestRef.current = false;
      if (!silent) setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadCategory();
  }, [loadCategory]);

  /* =========================================================
     LOAD SONGS FOR THIS CATEGORY

     Fetch actual songs rather than relying only on the
     category's song_count field.
  ========================================================= */

  const loadCategorySongs = useCallback(async ({ silent = false } = {}) => {
    if (!id) {
      setSongs([]);
      setSongsError("");
      setSongsLoading(false);
      return;
    }

    if (songsRequestRef.current) return;

    songsRequestRef.current = true;

    try {
      if (!silent) {
        setSongsLoading(true);
        setSongsError("");
      }

      const [response, artistsResponse] = await Promise.all([
        API.get("/songs"),
        API.get("/artists").catch((artistError) => {
          console.warn(
            "[CategoryDetails] Artist directory could not be loaded; using artist data included with songs.",
            artistError
          );
          return null;
        }),
      ]);
      const data = response.data;

      const allSongs = Array.isArray(data?.songs)
        ? data.songs
        : Array.isArray(data?.data?.songs)
          ? data.data.songs
          : Array.isArray(data?.data)
            ? data.data
            : Array.isArray(data)
              ? data
              : [];

      const artistData = artistsResponse?.data;
      const artistList = Array.isArray(artistData)
        ? artistData
        : Array.isArray(artistData?.artists)
          ? artistData.artists
          : Array.isArray(artistData?.data)
            ? artistData.data
            : Array.isArray(artistData?.data?.artists)
              ? artistData.data.artists
              : [];

      setArtists(artistList);

      const categorySongs = allSongs
        .filter((song) => String(song?.category_id) === String(id))
        .sort(compareSongsAlphabetically);

      // Keep song rows, Play All, and the player queue in the same A-Z order.
      setSongs(categorySongs);
      if (!silent) setSongsError("");

      console.log(
        `[CategoryDetails] Category ${id}:`,
        {
          categoryName: categoryRef.current?.name || "",
          totalSongsFromAPI: allSongs.length,
          matchingSongs: categorySongs.length,
          songs: categorySongs.map((song) => ({
            id: song.id,
            title: song.title,
            title_english: song.title_english,
            category_id: song.category_id,
            audio_url: song.audio_url,
            cover_url: song.cover_url,
          })),
        }
      );
    } catch (err) {
      console.error(
        "Load category songs error:",
        err
      );

      // Do not clear the existing song list if a background refresh fails.
      if (!silent || songs.length === 0) {
        if (songs.length === 0) setSongs([]);
        setSongsError(
          err?.response?.data?.message ||
            "Unable to load this category's songs. Please try again."
        );
      }
    } finally {
      songsRequestRef.current = false;
      if (!silent) setSongsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadCategorySongs();
  }, [loadCategorySongs]);

  /* =========================================================
     APP RESUME + PULL-TO-REFRESH
  ========================================================= */

  const refreshCategoryPage = useCallback(async () => {
    if (categoryRequestRef.current || songsRequestRef.current) return;

    setRefreshing(true);
    try {
      await Promise.all([
        loadCategory({ silent: true }),
        loadCategorySongs({ silent: true }),
      ]);
    } finally {
      setRefreshing(false);
      setPullDistance(0);
      pullDistanceRef.current = 0;
    }
  }, [loadCategory, loadCategorySongs]);

  useEffect(() => {
    const handleAppResume = () => {
      refreshCategoryPage();
    };

    window.addEventListener("keerthana:app-resume", handleAppResume);
    return () => {
      window.removeEventListener("keerthana:app-resume", handleAppResume);
    };
  }, [refreshCategoryPage]);

  const handleTouchStart = (event) => {
    if (window.scrollY <= 0 && event.touches?.length === 1) {
      touchStartYRef.current = event.touches[0].clientY;
    } else {
      touchStartYRef.current = null;
    }
  };

  const handleTouchMove = (event) => {
    if (touchStartYRef.current === null || window.scrollY > 0 || refreshing) return;

    const distance = Math.max(
      0,
      Math.min((event.touches[0].clientY - touchStartYRef.current) * 0.5, 88)
    );
    pullDistanceRef.current = distance;
    setPullDistance(distance);
  };

  const handleTouchEnd = () => {
    touchStartYRef.current = null;
    if (pullDistanceRef.current >= 62 && !refreshing) {
      refreshCategoryPage();
    } else {
      pullDistanceRef.current = 0;
      setPullDistance(0);
    }
  };

  const handleTouchCancel = () => {
    touchStartYRef.current = null;
    pullDistanceRef.current = 0;
    setPullDistance(0);
  };

  /* =========================================================
     CLOSE MENU ON OUTSIDE CLICK / ESCAPE
  ========================================================= */

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target)
      ) {
        setActiveMenu(null);
      }
    };

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setActiveMenu(null);
      }
    };

    document.addEventListener(
      "mousedown",
      handleOutsideClick
    );
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener(
        "mousedown",
        handleOutsideClick
      );
      document.removeEventListener(
        "keydown",
        handleEscape
      );
    };
  }, []);

  /* =========================================================
     SEARCH + ALPHABETICAL SONG ORDER (A-Z)
     Searches native/Telugu title, English title, artist,
     and language. Results remain sorted by English title.
  ========================================================= */

  const query = searchQuery.trim().toLocaleLowerCase();

  const filteredSongs = songs
    .filter((song) => {
      if (!query) return true;

      const searchableValues = [
        song?.title,
        song?.title_english,
        song?.artist_name,
        getSongEnglishArtistName(song, artists),
        ...(Array.isArray(song?.artists)
          ? song.artists.map((artist) =>
              typeof artist === "string"
                ? artist
                : artist?.name_english || artist?.english_name || artist?.nameEnglish || ""
            )
          : []),
        song?.language,
      ];

      return searchableValues.some((value) =>
        String(value || "").toLocaleLowerCase().includes(query)
      );
    })
    .sort(compareSongsAlphabetically);

  /* =========================================================
     CURRENT SONG HELPERS
  ========================================================= */

  const isCurrentSong = (song) =>
    currentSong?.id != null &&
    song?.id != null &&
    String(currentSong.id) === String(song.id);

  const categoryHasCurrentSong = songs.some(
    isCurrentSong
  );

  const categoryIsPlaying =
    categoryHasCurrentSong && Boolean(isPlaying);

  /* =========================================================
     PLAY / PAUSE SONG
  ========================================================= */

  const handleSongPlayPause = async (song) => {
    if (!song?.audio_url) {
      setNotice(
        "Audio is not available for this song."
      );
      return;
    }

    setActiveMenu(null);
    setNotice("");

    try {
      if (isCurrentSong(song)) {
        await togglePlay();
      } else {
        await playSong(song, songs);
      }
    } catch (err) {
      console.error("Song playback error:", err);

      setNotice(
        "Unable to play this song. Please try again."
      );
    }
  };

  /* =========================================================
     PLAY ALL CATEGORY SONGS
  ========================================================= */

  const handleCategoryPlayPause = async () => {
    const playableSongs = songs.filter(
      (song) => song?.audio_url
    );

    if (!playableSongs.length) {
      setNotice("No playable songs are available.");
      return;
    }

    setNotice("");

    try {
      if (categoryHasCurrentSong) {
        await togglePlay();
      } else {
        await playSong(
          playableSongs[0],
          playableSongs
        );
      }
    } catch (err) {
      console.error("Category playback error:", err);

      setNotice(
        "Unable to play these songs. Please try again."
      );
    }
  };

  /* =========================================================
     ADD TO QUEUE
  ========================================================= */

  const handleAddToQueue = (song) => {
    setActiveMenu(null);
    setNotice("");

    if (typeof addToQueue !== "function") {
      setNotice(
        "Queue is not available in the current player."
      );
      return;
    }

    try {
      addToQueue(song);

      setNotice(
        `Added "${song.title || "Song"}" to your queue.`
      );
    } catch (err) {
      console.error("Add to queue error:", err);

      setNotice(
        "Unable to add this song to the queue."
      );
    }
  };

  /* =========================================================
     ADD TO PLAYLIST
  ========================================================= */

  const handleAddToPlaylist = (song) => {
    setActiveMenu(null);

    navigate("/playlists", {
      state: {
        selectedSong: song,
        action: "add-song",
      },
    });
  };

  /* =========================================================
     BACK NAVIGATION
  ========================================================= */

  const goBack = () => {
    navigate("/categories");
  };

  /* =========================================================
     SONG COUNT

     Use actual fetched song records, not the database
     count alone, to represent the displayed collection.
  ========================================================= */

  const songCount = songs.length;

  /* =========================================================
     LOADING STATE
  ========================================================= */

  if (loading) {
    return (
      <div className="category-details-layout">
        <Sidebar />

        <main className="category-details-page">
          <button
            type="button"
            className="category-back-button"
            onClick={goBack}
          >
            <FaArrowLeft aria-hidden="true" />
            Back
          </button>

          <section
            className="categories-status"
            role="status"
            aria-live="polite"
          >
            <span className="categories-spinner" />
            <h2>Loading category</h2>
            <p>
              Getting your music category details...
            </p>
          </section>
        </main>
      </div>
    );
  }

  /* =========================================================
     ERROR STATE
  ========================================================= */

  if (error || !category) {
    return (
      <div className="category-details-layout">
        <Sidebar />

        <main className="category-details-page">
          <button
            type="button"
            className="category-back-button"
            onClick={goBack}
          >
            <FaArrowLeft aria-hidden="true" />
            Back
          </button>

          <section
            className="categories-status categories-error"
            role="alert"
          >
            <div className="categories-status-icon">
              <FaThLarge aria-hidden="true" />
            </div>

            <h2>Unable to open category</h2>
            <p>{error || "Category not found."}</p>

            <button
              type="button"
              className="categories-primary-button"
              onClick={loadCategory}
            >
              <FaRedo aria-hidden="true" />
              Try Again
            </button>
          </section>
        </main>
      </div>
    );
  }

  /* =========================================================
     PAGE
  ========================================================= */

  return (
    <div className="category-details-layout">
      <Sidebar />

      <main className="category-details-page">
        {/* BACK BUTTON */}

        <button
          type="button"
          className="category-back-button"
          onClick={goBack}
        >
          <FaArrowLeft aria-hidden="true" />
          Back
        </button>

        {/* CATEGORY PROFILE */}

        <section className="category-detail-card">
          <div className="category-detail-art">
            {getCategoryCoverUrl(category) ? (
              <img
                className="category-detail-cover"
                src={getCategoryCoverUrl(category)}
                alt={`${getCategoryEnglishName(category)} category cover`}
                loading="eager"
                onError={(event) => {
                  event.currentTarget.onerror = null;
                  event.currentTarget.style.display = "none";
                  event.currentTarget.parentElement?.classList.add(
                    "category-detail-art-fallback"
                  );
                }}
              />
            ) : (
              <FaMusic aria-hidden="true" />
            )}
          </div>

          <span className="categories-eyebrow">
            DISCOVER YOUR WORSHIP
          </span>

          <div className="category-detail-names">
            <h1>{getCategoryEnglishName(category)}</h1>

            {getCategoryTeluguName(category) && (
              <p className="category-detail-telugu-name">
                {getCategoryTeluguName(category)}
              </p>
            )}
          </div>

          {category.description && (
            <p className="category-detail-description">
              {category.description}
            </p>
          )}

          <div
            className={`category-detail-count ${
              songCount === 0
                ? "category-detail-count-empty"
                : ""
            }`}
            aria-live="polite"
          >
            <FaMusic aria-hidden="true" />

            <span>
              {songsLoading
                ? "Loading songs..."
                : `${songCount} ${
                    songCount === 1 ? "song" : "songs"
                  }`}
            </span>
          </div>

          {!songsLoading &&
            !songsError &&
            songCount === 0 && (
              <p className="category-detail-empty-message">
                No songs are currently available in this
                category.
              </p>
            )}
        </section>

        {/* SONG COLLECTION */}

        <section className="artist-songs-section category-songs-section">
          <div className="artist-songs-header">
            <div>
              <span className="artist-songs-overline">
                EXPLORE THIS CATEGORY
              </span>

              <h2>
                {query ? "Search Results" : "Songs"}
              </h2>
            </div>

            <span className="artist-track-count">
              {String(
                query
                  ? filteredSongs.length
                  : songCount
              ).padStart(2, "0")}{" "}
              {query
                ? filteredSongs.length === 1
                  ? "match"
                  : "matches"
                : "tracks"}
            </span>
          </div>

          {/* PLAY ALL */}

          <div className="category-play-all-bar">
            <button
              type="button"
              className="artist-profile-play"
              onClick={handleCategoryPlayPause}
              disabled={
                songsLoading ||
                !songs.some((song) => song?.audio_url)
              }
              aria-label={
                categoryIsPlaying
                  ? "Pause category songs"
                  : "Play all category songs"
              }
            >
              {categoryIsPlaying ? (
                <FaPause />
              ) : (
                <FaPlay />
              )}

              <span>
                {categoryIsPlaying
                  ? "Pause"
                  : "Play all"}
              </span>
            </button>
          </div>

          {/* STATUS MESSAGE */}

          {notice && (
            <div
              className="artist-notice"
              role="status"
              aria-live="polite"
            >
              <FaMusic />
              <span>{notice}</span>

              <button
                type="button"
                aria-label="Dismiss message"
                onClick={() => setNotice("")}
              >
                ×
              </button>
            </div>
          )}

          {/* SEARCH */}

          <div className="category-song-search">
            <input
              type="search"
              value={searchQuery}
              onChange={(event) =>
                setSearchQuery(event.target.value)
              }
              placeholder="Search songs in this category..."
              aria-label="Search songs in this category"
            />

            {searchQuery && (
              <button
                type="button"
                aria-label="Clear search"
                onClick={() => setSearchQuery("")}
              >
                <FaTimes />
              </button>
            )}
          </div>

          {/* SONGS LOADING */}

          {songsLoading && (
            <div
              className="categories-status"
              role="status"
              aria-live="polite"
            >
              <span className="categories-spinner" />
              <h2>Loading songs</h2>
              <p>
                Finding songs in this category...
              </p>
            </div>
          )}

          {/* SONG FETCH ERROR */}

          {!songsLoading && songsError && (
            <div
              className="categories-status categories-error"
              role="alert"
            >
              <h2>Unable to load songs</h2>
              <p>{songsError}</p>

              <button
                type="button"
                className="categories-primary-button"
                onClick={loadCategorySongs}
              >
                <FaRedo aria-hidden="true" />
                Try Again
              </button>
            </div>
          )}

          {/* SONG ROWS */}

          {!songsLoading &&
            !songsError &&
            filteredSongs.length > 0 && (
              <div
                className="artist-song-list category-song-list"
                id="category-song-list"
              >
                {filteredSongs.map((song) => {
                  const cover = song.cover_url
                    ? getMediaUrl(song.cover_url)
                    : "/images/default-cover.png";

                  const isCurrent = isCurrentSong(song);
                  const isSongPlaying =
                    isCurrent && isPlaying;

                  const menuOpen =
                    activeMenu === song.id;

                  const songTitle = getSongEnglishTitle(song);
                  const songTeluguTitle = getSongTeluguTitle(song);

                  return (
                    <article
                      key={song.id}
                      className={`artist-track-row ${
                        isCurrent ? "is-current" : ""
                      }`}
                    >
                      <div className="artist-track-artwork">
                        <img
                          src={cover}
                          alt={`${songTitle} cover`}
                          loading="lazy"
                          onError={(event) => {
                            event.currentTarget.onerror = null;
                            event.currentTarget.src =
                              "/images/default-cover.png";
                          }}
                        />
                      </div>

                      <button
                        type="button"
                        className="artist-track-details"
                        onClick={() =>
                          handleSongPlayPause(song)
                        }
                        disabled={!song?.audio_url}
                        aria-label={
                          isSongPlaying
                            ? `Pause ${songTitle}`
                            : `Play ${songTitle}`
                        }
                        title={
                          isSongPlaying
                            ? `Pause ${songTitle}`
                            : `Play ${songTitle}`
                        }
                      >
                        <strong
                          className={
                            isCurrent
                              ? "is-playing-title"
                              : ""
                          }
                        >
                          {songTitle}
                        </strong>

                        {songTeluguTitle && songTeluguTitle !== songTitle && (
                          <span className="category-song-english-title">
                            {songTeluguTitle}
                          </span>
                        )}

                        <span className="category-song-artist">
                          {getSongEnglishArtistName(song, artists)}
                        </span>
                      </button>

                      <div
                        className="artist-track-actions"
                        ref={menuOpen ? menuRef : null}
                      >
                        <button
                          type="button"
                          className={`artist-track-more ${
                            menuOpen ? "is-open" : ""
                          }`}
                          aria-label={`More options for ${songTitle}`}
                          aria-haspopup="menu"
                          aria-expanded={menuOpen}
                          onClick={(event) => {
                            event.stopPropagation();

                            setActiveMenu(
                              menuOpen ? null : song.id
                            );
                          }}
                        >
                          <FaEllipsisV />
                        </button>

                        {menuOpen && (
                          <div
                            className="artist-track-menu"
                            role="menu"
                          >
                            <button
                              type="button"
                              role="menuitem"
                              onClick={() =>
                                handleSongPlayPause(song)
                              }
                              disabled={!song?.audio_url}
                            >
                              {isSongPlaying ? (
                                <FaPause />
                              ) : (
                                <FaPlay />
                              )}

                              <span>
                                {isSongPlaying
                                  ? "Pause"
                                  : "Play"}
                              </span>
                            </button>

                            <button
                              type="button"
                              role="menuitem"
                              onClick={() =>
                                handleAddToQueue(song)
                              }
                            >
                              <FaPlus />
                              <span>Add to queue</span>
                            </button>

                            <button
                              type="button"
                              role="menuitem"
                              onClick={() =>
                                handleAddToPlaylist(song)
                              }
                            >
                              <FaListUl />
                              <span>Add to playlist</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            )}

          {/* EMPTY SEARCH / EMPTY CATEGORY */}

          {!songsLoading &&
            !songsError &&
            filteredSongs.length === 0 && (
              <div className="artist-songs-empty">
                <span className="artist-empty-icon">
                  <FaMusic />
                </span>

                <h3>
                  {query
                    ? "No matching songs"
                    : "No songs available"}
                </h3>

                <p>
                  {query
                    ? "Try another song title or clear your search."
                    : `Songs in ${getCategoryEnglishName(category)}${
                        getCategoryTeluguName(category)
                          ? ` (${getCategoryTeluguName(category)})`
                          : ""
                      } will appear here when they are available.`}
                </p>

                {query && (
                  <button
                    type="button"
                    className="artist-details-reset-search"
                    onClick={() => setSearchQuery("")}
                  >
                    <FaTimes />
                    Clear search
                  </button>
                )}
              </div>
            )}
        </section>
      </main>
    </div>
  );
}

export default CategoryDetails;
