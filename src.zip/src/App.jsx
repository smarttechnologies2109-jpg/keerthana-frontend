
import React, { useCallback, useEffect, useRef } from "react";
import { Capacitor } from "@capacitor/core";
import {
  AdMob,
  AdmobConsentStatus,
  AppOpenAdPluginEvents,
} from "@capacitor-community/admob";

import { usePlayer } from "./context/usePlayer";

import {
  Navigate,
  Routes,
  Route,
} from "react-router-dom";

/* =========================================================
   CONTEXT PROVIDERS
========================================================= */

import { PlayerProvider } from "./context/PlayerContext";
import { LikedSongsProvider } from "./context/LikedSongsContext";
import { NotificationsProvider } from "./context/NotificationsContext";

/* =========================================================
   LAYOUTS AND PROTECTED ROUTES
========================================================= */

import AppLayout from "./components/AppLayout";
import AdminLayout from "./components/admin/AdminLayout";
import AdminRoute from "./components/admin/AdminRoute";
import OwnerRoute from "./components/businessOwner/OwnerRoute";

/* =========================================================
   USER AUTHENTICATION
========================================================= */

import Login from "./pages/Login";
import Register from "./pages/Register";

/* =========================================================
   ADMIN AUTHENTICATION
========================================================= */

import AdminLogin from "./pages/admin/AdminLogin";
import AdminForgotPassword from "./pages/admin/AdminForgotPassword";

/* =========================================================
   USER PAGES
========================================================= */

import Home from "./pages/Home";
import Search from "./pages/Search";
import Library from "./pages/Library";
import LikedSongs from "./pages/LikedSongs";
import Playlists from "./pages/Playlists";
import PlaylistDetails from "./pages/PlaylistDetails";
import Artists from "./pages/Artists";
import ArtistDetails from "./pages/ArtistDetails";
import Albums from "./pages/Albums";
import AlbumDetails from "./pages/AlbumDetails";
import SongDetails from "./pages/SongDetails";
import Premium from "./pages/Premium";
import History from "./pages/History";
import Profile from "./pages/Profile";
import KeerthanaAIPage from "./pages/KeerthanaAI";
import MoodPlaylists from "./pages/MoodPlaylists";
import MoodSongs from "./pages/MoodSongs";
import Statistics from "./pages/Statistics";
import Ministries from "./pages/Ministries";
import MinistryDetails from "./pages/MinistryDetails";
import DownloadManager from "./pages/DownloadManager";
import AllSongs from "./pages/AllSongs";
import Notifications from "./pages/Notifications";
import Favorites from "./pages/Favorites";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Donations from "./pages/Donations";
import AboutUs from "./pages/AboutUs";
import ContactUs from "./pages/ContactUs";
import TermsAndConditions from "./pages/TermsAndConditions";
import Pricing from "./pages/Pricing";
import RefundCancellation from "./pages/RefundCancellation";
import CopyrightPolicy from "./pages/CopyrightPolicy";

import Categories from "./pages/Categories";
import CategoryDetails from "./pages/CategoryDetails";
import RecentlyAdded from "./pages/RecentlyAdded";

/* =========================================================
   ADMIN MANAGEMENT PAGES
========================================================= */

import AdminDashboard from "./pages/admin/AdminDashboard";
import ManageSongs from "./pages/admin/ManageSongs";
import AddSong from "./pages/admin/AddSong";
import EditSong from "./pages/admin/EditSong";
import AdminSongReports from "./pages/admin/AdminSongReports";
import ManageArtists from "./pages/admin/ManageArtists";
import ManageAlbums from "./pages/admin/ManageAlbums";
import ManageCategories from "./pages/admin/ManageCategories";
import ManageUsers from "./pages/admin/ManageUsers";
import ManageMinistries from "./pages/admin/ManageMinistries";

/* =========================================================
   BUSINESS OWNER PAGES
========================================================= */

import BusinessOwnerLogin from "./pages/businessOwner/BusinessOwnerLogin";
import BusinessOwnerForgotPassword from "./pages/businessOwner/BusinessOwnerForgotPassword";
import BusinessOwnerDashboard from "./pages/businessOwner/BusinessOwnerDashboard";
import BusinessOwnerUsers from "./pages/businessOwner/BusinessOwnerUsers";
import BusinessOwnerStatistics from "./pages/businessOwner/BusinessOwnerStatistics";
import BusinessOwnerMusic from "./pages/businessOwner/BusinessOwnerMusic";
import BusinessOwnerSongs from "./pages/businessOwner/BusinessOwnerSongs";
import BusinessOwnerAlbums from "./pages/businessOwner/BusinessOwnerAlbums";
import BusinessOwnerArtists from "./pages/businessOwner/BusinessOwnerArtists";
import BusinessOwnerCategories from "./pages/businessOwner/BusinessOwnerCategories";
import BusinessOwnerMinistries from "./pages/businessOwner/BusinessOwnerMinistries";

import AdFreeReward from "./pages/AdFreeReward";

/* =========================================================
   ANDROID BACK BUTTON
========================================================= */

import useAndroidBackButton from "./hooks/useAndroidBackButton";

function AndroidBackButtonHandler() {
  useAndroidBackButton();
  return null;
}

/* =========================================================
   KEERTHANA APP OPEN ADS

   - Uses Google's test App Open unit during development.
   - Loads without blocking app startup.
   - Shows on cold launch when an ad is ready and on resume.
   - Never interrupts active music playback.
   - Reloads after the previous App Open ad is closed.
========================================================= */

const APP_OPEN_AD_UNIT_ID =
  "ca-app-pub-4269202427991524/4146003724";

const APP_OPEN_AD_COOLDOWN = 5 * 60 * 1000;

function AppOpenAdHandler() {
  const { isPlaying } = usePlayer();

  const isLoadingRef = useRef(false);
  const isShowingRef = useRef(false);
  const isLoadedRef = useRef(false);
  const isPlayingRef = useRef(isPlaying);
  const lastShownAtRef = useRef(0);
  const activeRef = useRef(true);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  const loadAppOpenAd = useCallback(async () => {
    if (
      !Capacitor.isNativePlatform() ||
      Capacitor.getPlatform() !== "android" ||
      isLoadingRef.current ||
      isLoadedRef.current
    ) {
      return false;
    }

    isLoadingRef.current = true;

    try {
      let consentInfo = await AdMob.requestConsentInfo();

      if (
        consentInfo?.isConsentFormAvailable &&
        consentInfo?.status === AdmobConsentStatus.REQUIRED
      ) {
        consentInfo = await AdMob.showConsentForm();
      }

      if (!activeRef.current || !consentInfo?.canRequestAds) {
        console.info(
          "[KEERTHANA App Open] Ads are not currently allowed by consent."
        );
        return false;
      }

      // AdMobBanner also initializes the SDK. Calling initialize here
      // is safe and ensures App Open can initialize independently.
      await AdMob.initialize();

      if (!activeRef.current) return false;

      await AdMob.loadAppOpen({
        adId: APP_OPEN_AD_UNIT_ID,
      });

      console.info(
        "[KEERTHANA App Open] Google test App Open ad load requested."
      );

      return true;
    } catch (error) {
      console.error(
        "[KEERTHANA App Open] Ad load failed:",
        error
      );
      return false;
    } finally {
      isLoadingRef.current = false;
    }
  }, []);

  const showAppOpenAd = useCallback(async () => {
    if (
      !Capacitor.isNativePlatform() ||
      Capacitor.getPlatform() !== "android" ||
      isShowingRef.current ||
      isPlayingRef.current
    ) {
      if (isPlayingRef.current) {
        console.info(
          "[KEERTHANA App Open] Skipped because music is playing."
        );
      }
      return false;
    }

    if (
      Date.now() - lastShownAtRef.current <
      APP_OPEN_AD_COOLDOWN
    ) {
      console.info(
        "[KEERTHANA App Open] Skipped because of cooldown."
      );
      return false;
    }

    try {
      const loaded = await AdMob.isAppOpenLoaded({
        adId: APP_OPEN_AD_UNIT_ID,
      });

      if (!loaded?.value) {
        console.info(
          "[KEERTHANA App Open] No loaded ad available; requesting one."
        );
        loadAppOpenAd();
        return false;
      }

      isShowingRef.current = true;
      isLoadedRef.current = false;
      lastShownAtRef.current = Date.now();

      await AdMob.showAppOpen({
        adId: APP_OPEN_AD_UNIT_ID,
      });

      console.info(
        "[KEERTHANA App Open] Google test App Open ad display requested."
      );

      return true;
    } catch (error) {
      isShowingRef.current = false;
      isLoadedRef.current = false;

      console.error(
        "[KEERTHANA App Open] Ad display failed:",
        error
      );

      loadAppOpenAd();
      return false;
    }
  }, [loadAppOpenAd]);

  useEffect(() => {
    activeRef.current = true;

    if (
      !Capacitor.isNativePlatform() ||
      Capacitor.getPlatform() !== "android"
    ) {
      return () => {
        activeRef.current = false;
      };
    }

    let loadedListener;
    let failedListener;
    let closedListener;
    let openedListener;
    let failedShowListener;

    const handleResume = () => {
      // Give the app a moment to return to the foreground before showing.
      window.setTimeout(() => {
        if (activeRef.current) {
          showAppOpenAd();
        }
      }, 500);
    };

    const setup = async () => {
      try {
        loadedListener = await AdMob.addListener(
          AppOpenAdPluginEvents.Loaded,
          (info) => {
            isLoadedRef.current = true;
            isLoadingRef.current = false;
            console.info(
              "[KEERTHANA App Open] Test ad loaded:",
              info?.adUnitId
            );
          }
        );

        failedListener = await AdMob.addListener(
          AppOpenAdPluginEvents.FailedToLoad,
          (error) => {
            isLoadedRef.current = false;
            isLoadingRef.current = false;
            console.error(
              "[KEERTHANA App Open] Ad load failed:",
              error
            );
          }
        );

        openedListener = await AdMob.addListener(
          AppOpenAdPluginEvents.Opened,
          () => {
            console.info(
              "[KEERTHANA App Open] Ad opened."
            );
          }
        );

        closedListener = await AdMob.addListener(
          AppOpenAdPluginEvents.Closed,
          () => {
            isShowingRef.current = false;
            isLoadedRef.current = false;
            console.info(
              "[KEERTHANA App Open] Ad closed."
            );
            loadAppOpenAd();
          }
        );

        failedShowListener = await AdMob.addListener(
          AppOpenAdPluginEvents.FailedToShow,
          (error) => {
            isShowingRef.current = false;
            isLoadedRef.current = false;
            console.error(
              "[KEERTHANA App Open] Failed to show ad:",
              error
            );
            loadAppOpenAd();
          }
        );

        if (!activeRef.current) return;

        window.addEventListener(
          "keerthana:app-resume",
          handleResume
        );

        // Load in the background. Do not hold up app rendering.
        const requested = await loadAppOpenAd();

        if (requested && activeRef.current) {
          // Allow the native Loaded event to update the ready state.
          // The app can show on a later foreground transition if loading
          // has not completed by the time the first request returns.
          window.setTimeout(() => {
            if (activeRef.current) {
              showAppOpenAd();
            }
          }, 1200);
        }
      } catch (error) {
        console.error(
          "[KEERTHANA App Open] Setup failed:",
          error
        );
      }
    };

    setup();

    return () => {
      activeRef.current = false;
      window.removeEventListener(
        "keerthana:app-resume",
        handleResume
      );

      [
        loadedListener,
        failedListener,
        openedListener,
        closedListener,
        failedShowListener,
      ]
        .filter(Boolean)
        .forEach((listener) => {
          listener.remove().catch((error) => {
            console.warn(
              "[KEERTHANA App Open] Listener cleanup warning:",
              error
            );
          });
        });
    };
  }, [loadAppOpenAd, showAppOpenAd]);

  return null;
}

/* =========================================================
   KEERTHANA APP RESUME HANDLER

   Detects when the app returns to the foreground.

   Dispatches a custom event so individual pages can
   refresh their API data without reloading the app.

   IMPORTANT:
   - Does not reload the application.
   - Does not clear login sessions.
   - Does not remount PlayerProvider.
   - Does not interrupt music playback.
========================================================= */

function AppResumeHandler() {
  useEffect(() => {
    let wasHidden = document.visibilityState === "hidden";
    let wasBlurred = false;
    let lastRefreshTime = 0;

    const notifyAppResume = () => {
      if (document.visibilityState === "hidden") return;

      const now = Date.now();

      // visibilitychange and focus can fire together. Suppress only
      // duplicate events from the same foreground transition.
      if (now - lastRefreshTime < 700) return;

      lastRefreshTime = now;

      window.dispatchEvent(
        new CustomEvent("keerthana:app-resume", {
          detail: { timestamp: now },
        })
      );
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden") {
        wasHidden = true;
        return;
      }

      if (wasHidden) {
        wasHidden = false;
        wasBlurred = false;
        notifyAppResume();
      }
    };

    const handleBlur = () => {
      wasBlurred = true;
    };

    const handleFocus = () => {
      if (document.visibilityState === "hidden") return;

      // Some browsers/webviews do not reliably emit visibilitychange
      // when returning from another app or window.
      if (wasHidden || wasBlurred) {
        wasHidden = false;
        wasBlurred = false;
        notifyAppResume();
      }
    };

    const handlePageShow = (event) => {
      // Also refresh when a page is restored from the browser back-forward cache.
      if (event.persisted) {
        wasHidden = false;
        wasBlurred = false;
        notifyAppResume();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("blur", handleBlur);
    window.addEventListener("focus", handleFocus);
    window.addEventListener("pageshow", handlePageShow);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("blur", handleBlur);
      window.removeEventListener("focus", handleFocus);
      window.removeEventListener("pageshow", handlePageShow);
    };
  }, []);

  return null;
}

/* =========================================================
   PUBLIC HOME REDIRECT

   Visitors can access the homepage without login.
========================================================= */

function UserHomeRedirect() {
  return <Navigate to="/home" replace />;
}

/* =========================================================
   MAIN APP
========================================================= */

function App() {
  return (
    <PlayerProvider>
      <LikedSongsProvider>
        <NotificationsProvider>

          {/* ANDROID BACK BUTTON */}
          <AndroidBackButtonHandler />

          {/* APP FOREGROUND / RESUME LISTENER */}
          <AppResumeHandler />

          {/* APP OPEN ADS */}
          <AppOpenAdHandler />

          <Routes>

            {/* =========================================
                USER AUTHENTICATION
            ========================================= */}

            <Route
              path="/login"
              element={<Login />}
            />

            <Route
              path="/register"
              element={<Register />}
            />

            {/* =========================================
                ADMIN LOGIN
            ========================================= */}

            <Route
              path="/admin/login"
              element={<AdminLogin />}
            />

            <Route
              path="/admin/forgot-password"
              element={<AdminForgotPassword />}
            />

            {/* =========================================
                NORMAL KEERTHANA MUSIC APP
            ========================================= */}

            <Route element={<AppLayout />}>

              {/* PUBLIC PAGES */}

              <Route
                path="/terms-and-conditions"
                element={<TermsAndConditions />}
              />

              <Route
                path="/contact-us"
                element={<ContactUs />}
              />

              {/* ROOT - PUBLIC HOMEPAGE */}

              <Route
                path="/"
                element={<UserHomeRedirect />}
              />
           {/* AD-FREE REWARD */}

<Route
  path="/ad-free-reward"
  element={<AdFreeReward />}
/>
              {/* HOME */}

              <Route
                path="/home"
                element={<Home />}
              />

              {/* ALL SONGS */}

              <Route
                path="/all-songs"
                element={<AllSongs />}
              />

              {/* RECENTLY ADDED */}

              <Route
                path="/recently-added"
                element={<RecentlyAdded />}
              />

              {/* SONG DETAILS */}

              <Route
                path="/songs/:id"
                element={<SongDetails />}
              />

              {/* SEARCH */}

              <Route
                path="/search"
                element={<Search />}
              />

              {/* LIBRARY */}

              <Route
                path="/library"
                element={<Library />}
              />

              {/* LIKED SONGS */}

              <Route
                path="/liked-songs"
                element={<LikedSongs />}
              />

              {/* FAVORITES */}

              <Route
                path="/favorites"
                element={<Favorites />}
              />

              {/* PLAYLISTS */}

              <Route
                path="/playlists"
                element={<Playlists />}
              />

              <Route
                path="/playlists/:id"
                element={<PlaylistDetails />}
              />

              {/* DOWNLOADS */}

              <Route
                path="/downloads"
                element={<DownloadManager />}
              />

              {/* ARTISTS */}

              <Route
                path="/artists"
                element={<Artists />}
              />

              <Route
                path="/artists/:id"
                element={<ArtistDetails />}
              />

              {/* ALBUMS */}

              <Route
                path="/albums"
                element={<Albums />}
              />

              <Route
                path="/albums/:id"
                element={<AlbumDetails />}
              />

              {/* CATEGORIES */}

              <Route
                path="/categories"
                element={<Categories />}
              />

              <Route
                path="/categories/:id"
                element={<CategoryDetails />}
              />

              {/* MINISTRIES */}

              <Route
                path="/ministries"
                element={<Ministries />}
              />

              <Route
                path="/ministries/:id"
                element={<MinistryDetails />}
              />

              {/* PREMIUM */}

              <Route
                path="/premium"
                element={<Premium />}
              />

              {/* HISTORY */}

              <Route
                path="/history"
                element={<History />}
              />

              {/* PROFILE */}

              <Route
                path="/profile"
                element={<Profile />}
              />

              {/* NOTIFICATIONS */}

              <Route
                path="/notifications"
                element={<Notifications />}
              />

              {/* KEERTHANA AI */}

              <Route
                path="/keerthana-ai"
                element={<KeerthanaAIPage />}
              />

              {/* MOOD PLAYLISTS */}

              <Route
                path="/mood-playlists"
                element={<MoodPlaylists />}
              />

              {/* MOOD SONGS */}

              <Route
                path="/moods/:mood"
                element={<MoodSongs />}
              />

              {/* USER STATISTICS */}

              <Route
                path="/statistics"
                element={<Statistics />}
              />

              {/* PRIVACY POLICY */}

              <Route
                path="/privacy-policy"
                element={<PrivacyPolicy />}
              />

              {/* ABOUT US */}

              <Route
                path="/about-us"
                element={<AboutUs />}
              />

              {/* DONATIONS */}

              <Route
                path="/donations"
                element={<Donations />}
              />

              {/* PRICING */}

              <Route
                path="/pricing"
                element={<Pricing />}
              />

              {/* REFUND AND CANCELLATION */}

              <Route
                path="/refund-cancellation"
                element={<RefundCancellation />}
              />

              {/* COPYRIGHT POLICY */}

              <Route
                path="/copyright-policy"
                element={<CopyrightPolicy />}
              />

            </Route>

            {/* =========================================
                ADMIN PROTECTED AREA
            ========================================= */}

            <Route
              path="/admin"
              element={
                <AdminRoute>
                  <AdminLayout />
                </AdminRoute>
              }
            >

              <Route
                index
                element={
                  <Navigate
                    to="/admin/dashboard"
                    replace
                  />
                }
              />

              <Route
                path="dashboard"
                element={<AdminDashboard />}
              />

              <Route
                path="songs"
                element={<ManageSongs />}
              />

              <Route
                path="songs/add"
                element={<AddSong />}
              />

              <Route
                path="songs/:id/edit"
                element={<EditSong />}
              />

              <Route
                path="songs/reports"
                element={<AdminSongReports />}
              />

              <Route
                path="artists"
                element={<ManageArtists />}
              />

              <Route
                path="albums"
                element={<ManageAlbums />}
              />

              <Route
                path="categories"
                element={<ManageCategories />}
              />

              <Route
                path="users"
                element={<ManageUsers />}
              />

              <Route
                path="ministries"
                element={<ManageMinistries />}
              />

            </Route>

            {/* =========================================
                BUSINESS OWNER AUTHENTICATION
            ========================================= */}

            <Route
              path="/owner/login"
              element={<BusinessOwnerLogin />}
            />

            <Route
              path="/owner/forgot-password"
              element={<BusinessOwnerForgotPassword />}
            />

            {/* =========================================
                BUSINESS OWNER PROTECTED PAGES
            ========================================= */}

            <Route
              path="/owner/dashboard"
              element={
                <OwnerRoute>
                  <BusinessOwnerDashboard />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/users"
              element={
                <OwnerRoute>
                  <BusinessOwnerUsers />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/statistics"
              element={
                <OwnerRoute>
                  <BusinessOwnerStatistics />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/music"
              element={
                <OwnerRoute>
                  <BusinessOwnerMusic />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/music/songs"
              element={
                <OwnerRoute>
                  <BusinessOwnerSongs />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/music/albums"
              element={
                <OwnerRoute>
                  <BusinessOwnerAlbums />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/music/artists"
              element={
                <OwnerRoute>
                  <BusinessOwnerArtists />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/music/categories"
              element={
                <OwnerRoute>
                  <BusinessOwnerCategories />
                </OwnerRoute>
              }
            />

            <Route
              path="/owner/music/ministries"
              element={
                <OwnerRoute>
                  <BusinessOwnerMinistries />
                </OwnerRoute>
              }
            />

            {/* =========================================
                404 FALLBACK
            ========================================= */}

            <Route
              path="*"
              element={
                <div
                  style={{
                    minHeight: "100vh",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "#101827",
                    color: "#ffffff",
                    textAlign: "center",
                    padding: "24px",
                  }}
                >
                  <h1>404</h1>

                  <h2>Page Not Found</h2>

                  <p>
                    The requested KEERTHANA page does not exist.
                  </p>

                  <button
                    onClick={() => {
                      window.location.href = "/home";
                    }}
                    style={{
                      padding: "12px 24px",
                      borderRadius: "8px",
                      border: "none",
                      background: "#d4af65",
                      color: "#101827",
                      fontWeight: "600",
                      cursor: "pointer",
                    }}
                  >
                    Go to Home
                  </button>
                </div>
              }
            />

          </Routes>

        </NotificationsProvider>
      </LikedSongsProvider>
    </PlayerProvider>
  );
}

export default App;
